import { CloudProvider, Currency } from '../types/finops';

export const CURRENCY_RATES: Record<Currency, { symbol: string; rate: number }> = {
  USD: { symbol: '$', rate: 1.0 },
  EUR: { symbol: '€', rate: 0.92 },
  GBP: { symbol: '£', rate: 0.78 },
  JPY: { symbol: '¥', rate: 154.2 },
};

export function formatCurrency(amount: number, currency: Currency = 'USD', compact = false): string {
  const { symbol, rate } = CURRENCY_RATES[currency];
  const converted = amount * rate;

  if (currency === 'JPY') {
    if (compact) {
      if (Math.abs(converted) >= 1_000_000) {
        return `${symbol}${(converted / 1_000_000).toFixed(1)}M`;
      }
      if (Math.abs(converted) >= 1_000) {
        return `${symbol}${(converted / 1_000).toFixed(0)}K`;
      }
      return `${symbol}${Math.round(converted).toLocaleString()}`;
    }
    return `${symbol}${Math.round(converted).toLocaleString()}`;
  }

  if (compact) {
    if (Math.abs(converted) >= 1_000_000) {
      return `${symbol}${(converted / 1_000_000).toFixed(2)}M`;
    }
    if (Math.abs(converted) >= 1_000) {
      return `${symbol}${(converted / 1_000).toFixed(1)}k`;
    }
    return `${symbol}${converted.toFixed(0)}`;
  }

  return `${symbol}${converted.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatNumber(val: number): string {
  return val.toLocaleString();
}

export function formatPercent(val: number, withSign = true): string {
  const sign = withSign && val > 0 ? '+' : '';
  return `${sign}${val.toFixed(1)}%`;
}

export const PROVIDER_META: Record<
  CloudProvider,
  {
    name: string;
    shortName: string;
    color: string;
    bgHover: string;
    textColor: string;
    borderColor: string;
  }
> = {
  aws: {
    name: 'Amazon Web Services',
    shortName: 'AWS',
    color: '#f59e0b', // Amber-500
    bgHover: 'hover:border-amber-500/30',
    textColor: 'text-amber-400',
    borderColor: 'border-amber-500/20',
  },
  gcp: {
    name: 'Google Cloud Platform',
    shortName: 'GCP',
    color: '#38bdf8', // Sky-400
    bgHover: 'hover:border-sky-500/30',
    textColor: 'text-sky-400',
    borderColor: 'border-sky-500/20',
  },
  azure: {
    name: 'Microsoft Azure',
    shortName: 'Azure',
    color: '#60a5fa', // Blue-400
    bgHover: 'hover:border-blue-500/30',
    textColor: 'text-blue-400',
    borderColor: 'border-blue-500/20',
  },
  k8s: {
    name: 'Kubernetes Multi-Cluster',
    shortName: 'K8s',
    color: '#a78bfa', // Purple-400
    bgHover: 'hover:border-purple-500/30',
    textColor: 'text-purple-400',
    borderColor: 'border-purple-500/20',
  },
};
