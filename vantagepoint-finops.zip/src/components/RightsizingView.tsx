import React, { useState, useMemo } from 'react';
import {
  RightsizingRecommendation,
  RightsizingCategory,
  RiskLevel,
  RecommendationStatus,
  Currency,
} from '../types/finops';
import {
  formatCurrency,
  PROVIDER_META,
} from '../utils/formatters';
import {
  Sparkles,
  CheckCircle2,
  Code,
  SlidersHorizontal,
  Shield,
  ArrowRight,
  TrendingDown,
  X,
  Copy,
  Cpu,
  Layers,
  Database,
  HardDrive,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';

interface RightsizingViewProps {
  recommendations: RightsizingRecommendation[];
  currency: Currency;
  onApplyRecommendation: (id: string) => void;
  onDismissRecommendation: (id: string) => void;
}

export const RightsizingView: React.FC<RightsizingViewProps> = ({
  recommendations,
  currency,
  onApplyRecommendation,
  onDismissRecommendation,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedRisk, setSelectedRisk] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('open');
  const [inspectingRec, setInspectingRec] = useState<RightsizingRecommendation | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  // Filter recommendations
  const filteredRecs = useMemo(() => {
    return recommendations.filter((r) => {
      const matchCat =
        selectedCategory === 'all' ? true : r.category === selectedCategory;
      const matchRisk = selectedRisk === 'all' ? true : r.riskLevel === selectedRisk;
      const matchStatus =
        selectedStatus === 'all'
          ? true
          : selectedStatus === 'open'
          ? r.status === 'open'
          : r.status === selectedStatus;
      return matchCat && matchRisk && matchStatus;
    });
  }, [recommendations, selectedCategory, selectedRisk, selectedStatus]);

  // Aggregate metrics
  const totalOpenSavings = useMemo(() => {
    return recommendations
      .filter((r) => r.status === 'open')
      .reduce((sum, r) => sum + r.monthlySavings, 0);
  }, [recommendations]);

  const totalAppliedSavings = useMemo(() => {
    return recommendations
      .filter((r) => r.status === 'applied')
      .reduce((sum, r) => sum + r.monthlySavings, 0);
  }, [recommendations]);

  const annualizedPotential = totalOpenSavings * 12;

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const getCategoryIcon = (cat: RightsizingCategory) => {
    switch (cat) {
      case 'instance_downsize':
        return <Cpu className="w-3.5 h-3.5" />;
      case 'idle_cleanup':
        return <HardDrive className="w-3.5 h-3.5" />;
      case 'savings_plan':
        return <TrendingDown className="w-3.5 h-3.5" />;
      case 'storage_tiering':
        return <Database className="w-3.5 h-3.5" />;
      default:
        return <Layers className="w-3.5 h-3.5" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Automated Efficiency Engine</span>
            <span aria-hidden="true">·</span>
            <span>Cloud Resource Rightsizing</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400">Continuous telemetry analysis</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Rightsizing & Efficiency Recommendations
          </h1>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Last analysis: <span className="text-slate-200">Today, 08:30 UTC</span>
        </div>
      </div>

      {/* Aggregate Savings Summary Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Monthly Potential */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Available Monthly Savings</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums mb-1">
            {formatCurrency(totalOpenSavings, currency)}
            <span className="text-xs font-normal text-slate-400 ml-1">/ mo</span>
          </div>
          <div className="text-xs text-slate-400">
            Across {recommendations.filter((r) => r.status === 'open').length} actionable recommendations
          </div>
        </div>

        {/* Metric 2: Annualized Potential */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Annualized Cost Reduction</div>
          <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums mb-1">
            {formatCurrency(annualizedPotential, currency)}
            <span className="text-xs font-normal text-slate-400 ml-1">/ yr</span>
          </div>
          <div className="text-xs text-slate-400">
            Projected run rate impact upon full execution
          </div>
        </div>

        {/* Metric 3: Realized Savings */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Realized Savings (Month-to-Date)</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mb-1">
            {formatCurrency(totalAppliedSavings, currency)}
            <span className="text-xs font-normal text-slate-400 ml-1">/ mo</span>
          </div>
          <div className="text-xs text-emerald-400 font-mono flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>
              {recommendations.filter((r) => r.status === 'applied').length} Optimizations Applied
            </span>
          </div>
        </div>

        {/* Metric 4: Commitment Coverage Gauge */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Commitment Coverage</span>
            <span className="font-mono text-slate-200">64% / 85% Target</span>
          </div>
          <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden my-2">
            <div className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full" style={{ width: '64%' }} />
          </div>
          <div className="text-[11px] text-slate-400">
            1-Yr Compute Savings Plan boosts coverage by +18%
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 p-1">
        {/* Category Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs overflow-x-auto">
          {[
            { id: 'all', label: 'All Opportunities' },
            { id: 'instance_downsize', label: 'Compute Downsizing' },
            { id: 'idle_cleanup', label: 'Idle Resources' },
            { id: 'savings_plan', label: 'Commitment Plans' },
            { id: 'storage_tiering', label: 'Storage Tiering' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-slate-800 text-white font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Risk & Status Filters */}
        <div className="flex items-center gap-3 text-xs self-start lg:self-auto flex-wrap">
          {/* Status filter */}
          <div className="flex items-center gap-1 p-0.5 bg-slate-900 border border-slate-800 rounded-md">
            {(['open', 'applied', 'all'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setSelectedStatus(st)}
                className={`px-2.5 py-1 rounded capitalize transition-colors cursor-pointer ${
                  selectedStatus === st
                    ? 'bg-slate-800 text-white font-medium'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {/* Risk Level Filter */}
          <div className="flex items-center gap-1">
            <span className="text-slate-500">Risk:</span>
            {(['all', 'no_risk', 'low', 'medium'] as const).map((risk) => (
              <button
                key={risk}
                onClick={() => setSelectedRisk(risk)}
                className={`px-2 py-1 rounded capitalize border transition-colors cursor-pointer ${
                  selectedRisk === risk
                    ? 'bg-slate-800 text-white border-slate-700 font-medium'
                    : 'text-slate-400 border-transparent hover:text-slate-200'
                }`}
              >
                {risk === 'no_risk' ? 'No Risk' : risk}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Recommendations Cards / High-Density List */}
      <div className="space-y-3">
        {filteredRecs.length === 0 ? (
          <div className="p-8 text-center rounded-xl bg-slate-900/40 border border-slate-800/80 text-slate-400 text-sm">
            No rightsizing recommendations found matching selected filters.
          </div>
        ) : (
          filteredRecs.map((rec) => {
            const meta = PROVIDER_META[rec.provider];
            const isApplied = rec.status === 'applied';

            return (
              <div
                key={rec.id}
                className={`p-4 rounded-xl border transition-all ${
                  isApplied
                    ? 'bg-slate-950/40 border-slate-900 opacity-75'
                    : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700/80'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left info */}
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`font-mono font-semibold ${meta.textColor}`}>
                        {meta.shortName}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400 flex items-center gap-1">
                        {getCategoryIcon(rec.category)}
                        <span className="capitalize">{rec.category.replace('_', ' ')}</span>
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400 font-mono">{rec.region}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span
                        className={`font-medium ${
                          rec.riskLevel === 'no_risk'
                            ? 'text-emerald-400'
                            : rec.riskLevel === 'low'
                            ? 'text-cyan-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {rec.riskLevel === 'no_risk'
                          ? 'Zero Risk'
                          : `${rec.riskLevel.toUpperCase()} RISK`}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-500 font-mono text-[11px]">{rec.effort}</span>
                    </div>

                    <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2 truncate">
                      <span>{rec.title}</span>
                      {isApplied && (
                        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          APPLIED
                        </span>
                      )}
                    </h3>

                    {/* Current vs Proposed Spec Row */}
                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono pt-1">
                      <span className="text-slate-400 line-through">
                        {rec.currentConfig}
                      </span>
                      <ArrowRight className="w-3 h-3 text-slate-500" />
                      <span className="text-cyan-300 font-medium">
                        {rec.proposedConfig}
                      </span>
                    </div>

                    {/* Utilization telemetry if available */}
                    {(rec.cpuAvgPct !== undefined || rec.memoryAvgPct !== undefined) && (
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-0.5">
                        {rec.cpuAvgPct !== undefined && (
                          <span>
                            Avg CPU: <strong className="text-slate-200 font-mono">{rec.cpuAvgPct}%</strong>
                          </span>
                        )}
                        {rec.memoryAvgPct !== undefined && (
                          <span>
                            Avg RAM: <strong className="text-slate-200 font-mono">{rec.memoryAvgPct}%</strong>
                          </span>
                        )}
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-slate-500">Based on 30d CloudWatch/CloudMonitoring telemetry</span>
                      </div>
                    )}
                  </div>

                  {/* Right: Cost delta & Actions */}
                  <div className="flex items-center gap-6 shrink-0">
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Monthly Savings</div>
                      <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
                        {formatCurrency(rec.monthlySavings, currency)}
                        <span className="text-xs font-normal text-slate-400">/mo</span>
                      </div>
                      <div className="text-xs font-mono text-slate-500">
                        {formatCurrency(rec.monthlySavings * 12, currency)} / yr
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
                      {/* IaC Code Viewer */}
                      <button
                        onClick={() => setInspectingRec(rec)}
                        title="View Terraform / IaC Snippet"
                        className="p-1.5 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-md border border-slate-700 transition-colors cursor-pointer"
                      >
                        <Code className="w-4 h-4" />
                      </button>

                      {/* Apply / Rollback Action */}
                      {isApplied ? (
                        <button
                          onClick={() => onApplyRecommendation(rec.id)}
                          className="px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                        >
                          Rollback
                        </button>
                      ) : (
                        <button
                          onClick={() => onApplyRecommendation(rec.id)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md shadow-xs transition-colors cursor-pointer whitespace-nowrap"
                        >
                          Apply Action
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* IaC / Terraform Code Modal Drawer */}
      {inspectingRec && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2">
                <Code className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">
                  Infrastructure as Code (Terraform / Manifest)
                </h3>
              </div>
              <button
                onClick={() => setInspectingRec(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <h4 className="text-sm font-bold text-white mb-1">
                  {inspectingRec.title}
                </h4>
                <p className="text-slate-300 font-sans leading-relaxed">
                  {inspectingRec.reasoning}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-slate-400">
                  <span className="font-mono text-[11px]">main.tf / deployment.yaml</span>
                  <button
                    onClick={() => handleCopyCode(inspectingRec.iacSnippet)}
                    className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                </div>

                <pre className="p-4 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 font-mono text-xs overflow-x-auto whitespace-pre leading-relaxed">
                  {inspectingRec.iacSnippet}
                </pre>
              </div>

              <div className="p-3 bg-cyan-950/20 border border-cyan-800/30 rounded-lg text-cyan-300 text-[11px]">
                Tip: You can merge this snippet into your CI/CD repository or execute via Terraform Cloud / Atlantis pipeline.
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  onClick={() => setInspectingRec(null)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-md transition-colors cursor-pointer"
                >
                  Close
                </button>
                {inspectingRec.status !== 'applied' && (
                  <button
                    onClick={() => {
                      onApplyRecommendation(inspectingRec.id);
                      setInspectingRec(null);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors cursor-pointer"
                  >
                    Apply Optimization Now
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
