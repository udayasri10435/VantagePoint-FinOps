import React, { useState, useMemo } from 'react';
import {
  CostDataPoint,
  ServiceSpend,
  Currency,
  CloudProvider,
  CloudAccount,
} from '../types/finops';
import {
  formatCurrency,
  formatPercent,
  PROVIDER_META,
} from '../utils/formatters';
import {
  TrendingUp,
  AlertTriangle,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Search,
  Filter,
  Layers,
  BarChart2,
  Calendar,
  Info,
} from 'lucide-react';

interface SpendVisibilityProps {
  timeline: CostDataPoint[];
  services: ServiceSpend[];
  accounts: CloudAccount[];
  currency: Currency;
  onNavigateToAnomalies: () => void;
  onNavigateToRightsizing: () => void;
}

export const SpendVisibilityView: React.FC<SpendVisibilityProps> = ({
  timeline,
  services,
  accounts,
  currency,
  onNavigateToAnomalies,
  onNavigateToRightsizing,
}) => {
  const [chartDimension, setChartDimension] = useState<'provider' | 'category'>('provider');
  const [chartType, setChartType] = useState<'bar' | 'area'>('bar');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProvider, setSelectedProvider] = useState<string>('all');
  const [dateRange, setDateRange] = useState<'30d' | '14d' | '7d'>('30d');

  // Filter timeline based on dateRange
  const activeTimeline = useMemo(() => {
    const historicalOnly = timeline.filter((d) => !d.isForecast);
    const forecastPoints = timeline.filter((d) => d.isForecast);
    let count = 30;
    if (dateRange === '14d') count = 14;
    if (dateRange === '7d') count = 7;
    const slicedHistorical = historicalOnly.slice(-count);
    return [...slicedHistorical, ...forecastPoints];
  }, [timeline, dateRange]);

  // Aggregate Metrics
  const mtdSpend = useMemo(() => {
    return timeline
      .filter((d) => !d.isForecast)
      .reduce((sum, d) => sum + d.total, 0);
  }, [timeline]);

  const priorMonthSpend = 262300;
  const momChangePct = ((mtdSpend - priorMonthSpend) / priorMonthSpend) * 100;
  const projectedRunRate = mtdSpend * 1.203;
  const monthlyBudget = 320000;
  const budgetVariance = ((projectedRunRate - monthlyBudget) / monthlyBudget) * 100;

  // Max value for SVG scale
  const maxDaySpend = useMemo(() => {
    return Math.max(...activeTimeline.map((d) => d.total), 12000);
  }, [activeTimeline]);

  // Filtered Services Table
  const filteredServices = useMemo(() => {
    return services.filter((s) => {
      const matchesSearch =
        s.service.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory =
        selectedCategory === 'all' || s.category === selectedCategory;
      const matchesProvider =
        selectedProvider === 'all' || s.provider === selectedProvider;
      return matchesSearch && matchesCategory && matchesProvider;
    });
  }, [services, searchQuery, selectedCategory, selectedProvider]);

  const categories = useMemo(() => {
    return ['all', ...Array.from(new Set(services.map((s) => s.category)))];
  }, [services]);

  // SVG Chart Geometry
  const svgWidth = 860;
  const svgHeight = 260;
  const chartPadX = 35;
  const chartPadY = 25;
  const usableWidth = svgWidth - chartPadX * 2;
  const usableHeight = svgHeight - chartPadY * 2;
  const barWidth = Math.max(4, Math.min(18, (usableWidth / activeTimeline.length) * 0.72));

  return (
    <div className="space-y-6">
      {/* Page Header with Breadcrumb and Meta info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>FinOps Cloud Console</span>
            <span aria-hidden="true">·</span>
            <span>Multi-Cloud Aggregator</span>
            <span aria-hidden="true">·</span>
            <span>FOCUS 1.0 Aligned</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Cross-Cloud Spend Visibility
          </h1>
        </div>

        {/* Date Filter Segmented Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg shrink-0">
          {(['7d', '14d', '30d'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setDateRange(r)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                dateRange === r
                  ? 'bg-slate-800 text-white font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Last {r.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Grid (Zero-pill, high density, tabular numerals) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: MTD Spend */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700/80 transition-all">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Month-to-Date (MTD) Spend</span>
            <span className="text-slate-500 font-mono">Day 25/30</span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-white mb-2 tabular-nums">
            {formatCurrency(mtdSpend, currency)}
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <span
              className={`inline-flex items-center font-mono font-medium ${
                momChangePct > 0 ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {momChangePct > 0 ? (
                <ArrowUpRight className="w-3.5 h-3.5 inline mr-0.5" />
              ) : (
                <ArrowDownRight className="w-3.5 h-3.5 inline mr-0.5" />
              )}
              {formatPercent(momChangePct)}
            </span>
            <span className="text-slate-500">vs prior month cycle</span>
          </div>
        </div>

        {/* KPI 2: Month-End Forecast vs Budget */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700/80 transition-all">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Projected Run Rate</span>
            <span className="text-slate-500">Target: {formatCurrency(monthlyBudget, currency, true)}</span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-white mb-2 tabular-nums">
            {formatCurrency(projectedRunRate, currency)}
          </div>
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-rose-400 font-mono font-medium">
              +{formatPercent(budgetVariance, false)} over budget
            </span>
            <span className="text-slate-500">at current velocity</span>
          </div>
        </div>

        {/* KPI 3: Potential Monthly Savings */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700/80 transition-all cursor-pointer group" onClick={onNavigateToRightsizing}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Identified Savings</span>
            <span className="text-emerald-400 text-xs font-medium group-hover:underline">
              View 7 Actions →
            </span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-emerald-400 mb-2 tabular-nums">
            {formatCurrency(48390, currency)}
            <span className="text-xs font-normal text-slate-400 ml-1">/ mo</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Realized:</span>
            <span className="text-slate-200 font-mono font-semibold">
              {formatCurrency(19240, currency)}/mo
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-500">40% captured</span>
          </div>
        </div>

        {/* KPI 4: Active Anomalies */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700/80 transition-all cursor-pointer group" onClick={onNavigateToAnomalies}>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Active Cost Anomalies</span>
            <span className="text-rose-400 text-xs font-medium group-hover:underline">
              Investigate →
            </span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-rose-400 mb-2 tabular-nums">
            2 Spikes
            <span className="text-xs font-normal text-slate-400 ml-2">unresolved</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span className="text-rose-400 font-mono font-medium">
              +{formatCurrency(2260, currency)}/day
            </span>
            <span className="text-slate-500">excess burn rate</span>
          </div>
        </div>
      </div>

      {/* Main Chart Section: Multi-Cloud Spend Timeline */}
      <div className="p-5 rounded-xl bg-slate-900/40 border border-slate-800/80">
        {/* Chart Header & Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-base font-semibold text-white">
              Daily Spend Trajectory & Forecast
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span>Stacked daily breakdown across AWS, GCP, Azure, and K8s clusters</span>
              <span aria-hidden="true">·</span>
              <span className="text-cyan-400">Dashed band indicates 5-day ML projection</span>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start lg:self-auto flex-wrap">
            {/* Legend */}
            <div className="flex items-center gap-4 text-xs font-medium">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-amber-500" />
                <span className="text-slate-300">AWS</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-sky-400" />
                <span className="text-slate-300">GCP</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-blue-500" />
                <span className="text-slate-300">Azure</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-purple-400" />
                <span className="text-slate-300">K8s</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 border-t border-dashed border-rose-400" />
                <span className="text-rose-400 font-mono">Budget</span>
              </div>
            </div>

            {/* Chart Type Toggle */}
            <div className="flex items-center p-0.5 bg-slate-900 border border-slate-800 rounded-md text-xs">
              <button
                onClick={() => setChartType('bar')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  chartType === 'bar' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400'
                }`}
              >
                Bars
              </button>
              <button
                onClick={() => setChartType('area')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  chartType === 'area' ? 'bg-slate-800 text-white font-medium' : 'text-slate-400'
                }`}
              >
                Area
              </button>
            </div>
          </div>
        </div>

        {/* Responsive Interactive SVG Chart */}
        <div className="relative w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full min-w-[700px] h-64 select-none"
            onMouseLeave={() => setHoveredIndex(null)}
          >
            <defs>
              <linearGradient id="awsGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.45" />
              </linearGradient>
              <linearGradient id="gcpGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.45" />
              </linearGradient>
              <linearGradient id="azureGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.45" />
              </linearGradient>
              <linearGradient id="k8sGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#a855f7" stopOpacity="0.85" />
                <stop offset="100%" stopColor="#a855f7" stopOpacity="0.45" />
              </linearGradient>

              {/* Forecast Pattern */}
              <pattern
                id="forecastHatch"
                width="6"
                height="6"
                patternTransform="rotate(45 0 0)"
                patternUnits="userSpaceOnUse"
              >
                <line x1="0" y1="0" x2="0" y2="6" stroke="#475569" strokeWidth="1.5" />
              </pattern>
            </defs>

            {/* Gridlines */}
            {[0.25, 0.5, 0.75, 1.0].map((ratio) => {
              const val = maxDaySpend * ratio;
              const y = svgHeight - chartPadY - usableHeight * ratio;
              return (
                <g key={ratio}>
                  <line
                    x1={chartPadX}
                    y1={y}
                    x2={svgWidth - chartPadX}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                    strokeWidth="1"
                  />
                  <text
                    x={chartPadX - 6}
                    y={y + 3}
                    textAnchor="end"
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {formatCurrency(val, currency, true)}
                  </text>
                </g>
              );
            })}

            {/* Budget Line */}
            {(() => {
              const budgetY =
                svgHeight - chartPadY - (9800 / maxDaySpend) * usableHeight;
              return (
                <g>
                  <line
                    x1={chartPadX}
                    y1={budgetY}
                    x2={svgWidth - chartPadX}
                    y2={budgetY}
                    stroke="#fb7185"
                    strokeDasharray="6 3"
                    strokeWidth="1.5"
                  />
                  <text
                    x={svgWidth - chartPadX + 6}
                    y={budgetY + 3}
                    textAnchor="start"
                    fill="#fb7185"
                    fontSize="10"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    Budget
                  </text>
                </g>
              );
            })()}

            {/* Area or Bar Rendering */}
            {chartType === 'bar' ? (
              // Stacked Bar Chart
              activeTimeline.map((d, idx) => {
                const x =
                  chartPadX +
                  (idx / (activeTimeline.length - 1 || 1)) * (usableWidth - barWidth);
                const awsHeight = (d.aws / maxDaySpend) * usableHeight;
                const gcpHeight = (d.gcp / maxDaySpend) * usableHeight;
                const azHeight = (d.azure / maxDaySpend) * usableHeight;
                const k8sHeight = (d.k8s / maxDaySpend) * usableHeight;

                const baseBottom = svgHeight - chartPadY;
                const yAws = baseBottom - awsHeight;
                const yGcp = yAws - gcpHeight;
                const yAz = yGcp - azHeight;
                const yK8s = yAz - k8sHeight;

                const isHovered = hoveredIndex === idx;

                return (
                  <g
                    key={d.date}
                    onMouseEnter={() => setHoveredIndex(idx)}
                    className="cursor-pointer"
                  >
                    {/* Hover highlight column */}
                    {isHovered && (
                      <rect
                        x={x - 4}
                        y={chartPadY}
                        width={barWidth + 8}
                        height={usableHeight}
                        fill="#334155"
                        opacity="0.25"
                        rx="3"
                      />
                    )}

                    {/* Forecast Hatch Backdrop if forecast */}
                    {d.isForecast && (
                      <rect
                        x={x}
                        y={yK8s}
                        width={barWidth}
                        height={awsHeight + gcpHeight + azHeight + k8sHeight}
                        fill="url(#forecastHatch)"
                        opacity="0.3"
                      />
                    )}

                    {/* AWS segment */}
                    <rect
                      x={x}
                      y={yAws}
                      width={barWidth}
                      height={awsHeight}
                      fill="url(#awsGrad)"
                      opacity={d.isForecast ? 0.6 : 1}
                    />

                    {/* GCP segment */}
                    <rect
                      x={x}
                      y={yGcp}
                      width={barWidth}
                      height={gcpHeight}
                      fill="url(#gcpGrad)"
                      opacity={d.isForecast ? 0.6 : 1}
                    />

                    {/* Azure segment */}
                    <rect
                      x={x}
                      y={yAz}
                      width={barWidth}
                      height={azHeight}
                      fill="url(#azureGrad)"
                      opacity={d.isForecast ? 0.6 : 1}
                    />

                    {/* K8s segment */}
                    <rect
                      x={x}
                      y={yK8s}
                      width={barWidth}
                      height={k8sHeight}
                      fill="url(#k8sGrad)"
                      rx="1"
                      opacity={d.isForecast ? 0.6 : 1}
                    />

                    {/* X-axis date labels (sample every few points) */}
                    {(idx % Math.ceil(activeTimeline.length / 8) === 0 ||
                      idx === activeTimeline.length - 1) && (
                      <text
                        x={x + barWidth / 2}
                        y={svgHeight - chartPadY + 16}
                        textAnchor="middle"
                        fill="#64748b"
                        fontSize="10"
                        fontFamily="JetBrains Mono, monospace"
                      >
                        {d.dayLabel.split(' ')[0]} {d.dayLabel.split(' ')[1]}
                      </text>
                    )}
                  </g>
                );
              })
            ) : (
              // Stacked Area Chart (SVG Polygons)
              (() => {
                const pts = activeTimeline;
                const getX = (i: number) =>
                  chartPadX + (i / (pts.length - 1 || 1)) * usableWidth;

                // Points for lines
                const k8sPoints: string[] = [];
                const azPoints: string[] = [];
                const gcpPoints: string[] = [];
                const awsPoints: string[] = [];

                pts.forEach((d, i) => {
                  const x = getX(i);
                  const baseBottom = svgHeight - chartPadY;
                  const yAws = baseBottom - (d.aws / maxDaySpend) * usableHeight;
                  const yGcp =
                    baseBottom - ((d.aws + d.gcp) / maxDaySpend) * usableHeight;
                  const yAz =
                    baseBottom -
                    ((d.aws + d.gcp + d.azure) / maxDaySpend) * usableHeight;
                  const yTotal =
                    baseBottom - (d.total / maxDaySpend) * usableHeight;

                  awsPoints.push(`${x},${yAws}`);
                  gcpPoints.push(`${x},${yGcp}`);
                  azPoints.push(`${x},${yAz}`);
                  k8sPoints.push(`${x},${yTotal}`);
                });

                // Polygons
                const baseLine = `${getX(pts.length - 1)},${svgHeight - chartPadY} ${getX(0)},${svgHeight - chartPadY}`;

                return (
                  <g>
                    {/* AWS Area */}
                    <polygon
                      points={`${awsPoints.join(' ')} ${baseLine}`}
                      fill="url(#awsGrad)"
                      opacity="0.8"
                    />
                    {/* GCP Area */}
                    <polygon
                      points={`${gcpPoints.join(' ')} ${awsPoints.slice().reverse().join(' ')}`}
                      fill="url(#gcpGrad)"
                      opacity="0.8"
                    />
                    {/* Azure Area */}
                    <polygon
                      points={`${azPoints.join(' ')} ${gcpPoints.slice().reverse().join(' ')}`}
                      fill="url(#azureGrad)"
                      opacity="0.8"
                    />
                    {/* K8s Area */}
                    <polygon
                      points={`${k8sPoints.join(' ')} ${azPoints.slice().reverse().join(' ')}`}
                      fill="url(#k8sGrad)"
                      opacity="0.8"
                    />

                    {/* Interactive hover lines */}
                    {pts.map((d, idx) => {
                      const x = getX(idx);
                      const isHovered = hoveredIndex === idx;
                      return (
                        <g
                          key={d.date}
                          onMouseEnter={() => setHoveredIndex(idx)}
                          className="cursor-pointer"
                        >
                          <rect
                            x={x - 8}
                            y={chartPadY}
                            width={16}
                            height={usableHeight}
                            fill="transparent"
                          />
                          {isHovered && (
                            <line
                              x1={x}
                              y1={chartPadY}
                              x2={x}
                              y2={svgHeight - chartPadY}
                              stroke="#38bdf8"
                              strokeWidth="1.5"
                              strokeDasharray="3 3"
                            />
                          )}
                          {(idx % Math.ceil(pts.length / 8) === 0 ||
                            idx === pts.length - 1) && (
                            <text
                              x={x}
                              y={svgHeight - chartPadY + 16}
                              textAnchor="middle"
                              fill="#64748b"
                              fontSize="10"
                              fontFamily="JetBrains Mono, monospace"
                            >
                              {d.dayLabel.split(' ')[0]} {d.dayLabel.split(' ')[1]}
                            </text>
                          )}
                        </g>
                      );
                    })}
                  </g>
                );
              })()
            )}
          </svg>

          {/* Floating Data Inspector Tooltip */}
          {hoveredIndex !== null && activeTimeline[hoveredIndex] && (
            <div
              className="absolute top-3 left-1/2 -translate-x-1/2 pointer-events-none z-20 bg-slate-900/95 border border-slate-700/80 rounded-lg p-3 shadow-xl backdrop-blur-md text-xs font-mono min-w-[260px]"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2 font-sans font-semibold text-slate-200">
                <span>{activeTimeline[hoveredIndex].date}</span>
                {activeTimeline[hoveredIndex].isForecast ? (
                  <span className="text-cyan-400 text-xs">ML Forecast</span>
                ) : (
                  <span className="text-slate-400 text-xs">Actual Audit</span>
                )}
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    AWS:
                  </span>
                  <span className="font-semibold text-white">
                    {formatCurrency(activeTimeline[hoveredIndex].aws, currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-sky-400" />
                    GCP:
                  </span>
                  <span className="font-semibold text-white">
                    {formatCurrency(activeTimeline[hoveredIndex].gcp, currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-500" />
                    Azure:
                  </span>
                  <span className="font-semibold text-white">
                    {formatCurrency(activeTimeline[hoveredIndex].azure, currency)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                    K8s:
                  </span>
                  <span className="font-semibold text-white">
                    {formatCurrency(activeTimeline[hoveredIndex].k8s, currency)}
                  </span>
                </div>

                <div className="border-t border-slate-800 pt-1.5 flex items-center justify-between font-bold text-white">
                  <span>Day Total:</span>
                  <span className="text-cyan-300 text-sm">
                    {formatCurrency(activeTimeline[hoveredIndex].total, currency)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Cloud Account Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {accounts.map((acc) => {
          const meta = PROVIDER_META[acc.provider];
          const pctOfTotal = ((acc.monthlySpend / mtdSpend) * 100).toFixed(1);
          return (
            <div
              key={acc.id}
              className={`p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 ${meta.bgHover} transition-all`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className={`text-xs font-semibold ${meta.textColor}`}>
                  {meta.shortName}
                </span>
                <span className="text-xs text-slate-500 font-mono">
                  {acc.lastSync}
                </span>
              </div>
              <h3 className="text-sm font-semibold text-white truncate mb-1">
                {acc.name}
              </h3>
              <div className="text-xs font-mono text-slate-400 truncate mb-3">
                {acc.accountId}
              </div>
              <div className="flex items-baseline justify-between border-t border-slate-800/60 pt-3">
                <div>
                  <div className="text-xs text-slate-500">Spend MTD</div>
                  <div className="text-base font-bold font-mono text-white tabular-nums">
                    {formatCurrency(acc.monthlySpend, currency)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Share</div>
                  <div className="text-sm font-mono text-slate-300">
                    {pctOfTotal}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* High-Density Multi-Cloud Service Breakdown Table */}
      <div className="rounded-xl bg-slate-900/40 border border-slate-800/80 overflow-hidden">
        {/* Table Controls Bar */}
        <div className="p-4 border-b border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-white">
              Service Cost Breakdown
            </h2>
            <div className="text-xs text-slate-400">
              Showing {filteredServices.length} cloud services ranked by MTD spend
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                type="text"
                placeholder="Search services or categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded-md text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors w-48 sm:w-56"
              />
            </div>

            {/* Provider Filter */}
            <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md text-xs">
              {(['all', 'aws', 'gcp', 'azure', 'k8s'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => setSelectedProvider(p)}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer uppercase font-mono ${
                    selectedProvider === p
                      ? 'bg-slate-800 text-white font-medium'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>

            {/* Category Dropdown */}
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="text-xs bg-slate-950 border border-slate-800 rounded-md px-2.5 py-1.5 text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'all' ? 'All Categories' : c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* High-Density Data Grid (Tabular-nums, compact rows) */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800/80 bg-slate-950/60 text-xs font-medium text-slate-400">
                <th className="py-2.5 px-4">Cloud Service</th>
                <th className="py-2.5 px-4">Provider</th>
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4 text-right">MTD Spend</th>
                <th className="py-2.5 px-4 text-right">Share of Total</th>
                <th className="py-2.5 px-4 text-right">MoM Change</th>
                <th className="py-2.5 px-4 text-right">Unit Metric</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50 text-xs">
              {filteredServices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No cloud services matched your filter query.
                  </td>
                </tr>
              ) : (
                filteredServices.map((item) => {
                  const meta = PROVIDER_META[item.provider];
                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-800/30 transition-colors group"
                    >
                      <td className="py-3 px-4 font-medium text-white">
                        <div className="flex items-center gap-2">
                          <span
                            className="w-1.5 h-1.5 rounded-full"
                            style={{ backgroundColor: meta.color }}
                          />
                          <span>{item.service}</span>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-mono text-slate-400">
                        {meta.shortName}
                      </td>

                      <td className="py-3 px-4 text-slate-300">
                        {item.category}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-semibold text-white tabular-nums">
                        {formatCurrency(item.mtdSpend, currency)}
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-300 tabular-nums">
                        <div className="flex items-center justify-end gap-2">
                          <span>{item.percentageOfTotal.toFixed(1)}%</span>
                          <div className="w-12 h-1.5 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
                            <div
                              className="h-full rounded-full"
                              style={{
                                width: `${Math.min(100, item.percentageOfTotal * 3)}%`,
                                backgroundColor: meta.color,
                              }}
                            />
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums">
                        <span
                          className={
                            item.changePct > 15
                              ? 'text-rose-400 font-semibold'
                              : item.changePct > 0
                              ? 'text-amber-400'
                              : 'text-emerald-400'
                          }
                        >
                          {formatPercent(item.changePct)}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right font-mono text-slate-400">
                        {item.unitCostMetric || '—'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
