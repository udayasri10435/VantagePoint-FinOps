import React, { useState } from 'react';
import {
  Currency,
  Anomaly,
  RightsizingRecommendation,
  ChargebackUnit,
  CloudAccount,
  AnomalyStatus,
} from './types/finops';
import {
  INITIAL_ACCOUNTS,
  GENERATE_COST_TIMELINE,
  INITIAL_SERVICES,
  INITIAL_ANOMALIES,
  INITIAL_RECOMMENDATIONS,
  INITIAL_CHARGEBACK_UNITS,
  SHARED_COST_POOLS,
} from './data/mockFinOpsData';
import { Navbar } from './components/Navbar';
import { SpendVisibilityView } from './components/SpendVisibilityView';
import { AnomalyAlertsView } from './components/AnomalyAlertsView';
import { RightsizingView } from './components/RightsizingView';
import { ChargebackView } from './components/ChargebackView';
import { ConnectedCloudsView } from './components/ConnectedCloudsView';
import { SimulateAnomalyModal } from './components/SimulateAnomalyModal';
import { ExportReportModal } from './components/ExportReportModal';
import { AlertTriangle, CheckCircle2, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'spend' | 'anomalies' | 'rightsizing' | 'chargeback' | 'accounts'
  >('spend');
  const [currency, setCurrency] = useState<Currency>('USD');

  // Application State
  const [accounts, setAccounts] = useState<CloudAccount[]>(INITIAL_ACCOUNTS);
  const [timeline, setTimeline] = useState(GENERATE_COST_TIMELINE);
  const [services, setServices] = useState(INITIAL_SERVICES);
  const [anomalies, setAnomalies] = useState<Anomaly[]>(INITIAL_ANOMALIES);
  const [recommendations, setRecommendations] = useState<RightsizingRecommendation[]>(
    INITIAL_RECOMMENDATIONS
  );
  const [chargebackUnits, setChargebackUnits] = useState<ChargebackUnit[]>(
    INITIAL_CHARGEBACK_UNITS
  );
  const [sharedPools, setSharedPools] = useState(SHARED_COST_POOLS);

  // Modals & Notifications
  const [isSimulateModalOpen, setIsSimulateModalOpen] = useState(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<{
    text: string;
    type: 'success' | 'alert';
  } | null>(null);

  const showToast = (text: string, type: 'success' | 'alert' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Actions
  const handleUpdateAnomalyStatus = (id: string, status: AnomalyStatus) => {
    setAnomalies((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status } : a))
    );
    showToast(
      status === 'resolved'
        ? 'Anomaly marked as resolved.'
        : 'Anomaly incident acknowledged and moved to investigation.'
    );
  };

  const handleApplyRecommendation = (id: string) => {
    setRecommendations((prev) =>
      prev.map((r) => {
        if (r.id === id) {
          const nextStatus = r.status === 'applied' ? 'open' : 'applied';
          showToast(
            nextStatus === 'applied'
              ? `Applied: ${r.title} (+$${r.monthlySavings}/mo realized savings)`
              : `Optimization rolled back: ${r.title}`
          );
          return { ...r, status: nextStatus };
        }
        return r;
      })
    );
  };

  const handleDismissRecommendation = (id: string) => {
    setRecommendations((prev) =>
      prev.map((r) => (r.id === id ? { ...r, status: 'dismissed' } : r))
    );
    showToast('Recommendation dismissed.');
  };

  const handleAddAnomaly = (anomaly: Anomaly) => {
    setAnomalies((prev) => [anomaly, ...prev]);
    showToast(
      `CRITICAL COST SPIKE DETECTED: ${anomaly.title} (+$${anomaly.costSpikePerDay}/day)`,
      'alert'
    );
    setActiveTab('anomalies');
  };

  const handleAddAccount = (acc: CloudAccount) => {
    setAccounts((prev) => [...prev, acc]);
    showToast(`Connected ${acc.name} (${acc.provider.toUpperCase()}) successfully.`);
  };

  const handleRefreshSync = (id: string) => {
    setAccounts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, lastSync: 'Just now' } : a))
    );
    showToast('Cloud billing telemetry synchronized.');
  };

  const handleLoadPreset = (preset: 'enterprise' | 'ai_startup' | 'fintech') => {
    if (preset === 'ai_startup') {
      setServices((prev) =>
        prev.map((s) =>
          s.category === 'AI & ML' || s.category === 'Containers'
            ? { ...s, mtdSpend: Math.round(s.mtdSpend * 2.4) }
            : s
        )
      );
      showToast('Loaded AI / Foundation Model Startup profile ($410k/mo).');
    } else if (preset === 'fintech') {
      setServices((prev) =>
        prev.map((s) =>
          s.category === 'Database' || s.category === 'Networking'
            ? { ...s, mtdSpend: Math.round(s.mtdSpend * 1.6) }
            : s
        )
      );
      showToast('Loaded High-Compliance Fintech profile ($190k/mo).');
    } else {
      setServices(INITIAL_SERVICES);
      showToast('Loaded Global Enterprise SaaS profile ($284k/mo).');
    }
  };

  const activeAnomalyCount = anomalies.filter(
    (a) => a.status === 'active' || a.status === 'investigating'
  ).length;

  const mtdSpend = timeline
    .filter((d) => !d.isForecast)
    .reduce((sum, d) => sum + d.total, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currency={currency}
        onSelectCurrency={setCurrency}
        activeAnomalyCount={activeAnomalyCount}
        onOpenSimulateModal={() => setIsSimulateModalOpen(true)}
        onOpenExportModal={() => setIsExportModalOpen(true)}
      />

      {/* Floating System Toast */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 flex items-center gap-2 px-4 py-2.5 rounded-lg shadow-2xl backdrop-blur-md text-xs font-mono border animate-in slide-in-from-bottom-3 duration-200 bg-slate-900/95 border-slate-700 text-white">
          {toastMessage.type === 'alert' ? (
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          )}
          <span className="font-sans font-medium">{toastMessage.text}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'spend' && (
          <SpendVisibilityView
            timeline={timeline}
            services={services}
            accounts={accounts}
            currency={currency}
            onNavigateToAnomalies={() => setActiveTab('anomalies')}
            onNavigateToRightsizing={() => setActiveTab('rightsizing')}
          />
        )}

        {activeTab === 'anomalies' && (
          <AnomalyAlertsView
            anomalies={anomalies}
            currency={currency}
            onUpdateStatus={handleUpdateAnomalyStatus}
            onOpenSimulateModal={() => setIsSimulateModalOpen(true)}
          />
        )}

        {activeTab === 'rightsizing' && (
          <RightsizingView
            recommendations={recommendations}
            currency={currency}
            onApplyRecommendation={handleApplyRecommendation}
            onDismissRecommendation={handleDismissRecommendation}
          />
        )}

        {activeTab === 'chargeback' && (
          <ChargebackView
            chargebackUnits={chargebackUnits}
            sharedPools={sharedPools}
            currency={currency}
          />
        )}

        {activeTab === 'accounts' && (
          <ConnectedCloudsView
            accounts={accounts}
            currency={currency}
            onAddAccount={handleAddAccount}
            onRefreshSync={handleRefreshSync}
            onLoadPreset={handleLoadPreset}
          />
        )}
      </main>

      {/* Modals */}
      <SimulateAnomalyModal
        isOpen={isSimulateModalOpen}
        onClose={() => setIsSimulateModalOpen(false)}
        onAddAnomaly={handleAddAnomaly}
      />

      <ExportReportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        currency={currency}
        mtdSpend={mtdSpend}
        services={services}
        anomalies={anomalies}
        recommendations={recommendations}
        chargebackUnits={chargebackUnits}
      />

      {/* Minimal Footer compliant with Anti-Slop (No fake telemetry tickers or fake worker IDs) */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span>VantagePoint FinOps Platform</span>
            <span aria-hidden="true">·</span>
            <span>Multi-Cloud Cost Intelligence</span>
            <span aria-hidden="true">·</span>
            <span>FOCUS 1.0 Compliant</span>
          </div>
          <div className="text-slate-500 font-mono text-[11px]">
            Connected to 4 Cloud Tenancies (AWS, GCP, Azure, K8s)
          </div>
        </div>
      </footer>
    </div>
  );
}
