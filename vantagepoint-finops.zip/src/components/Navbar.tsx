import React from 'react';
import { Currency } from '../types/finops';
import { Cloud, Sliders, Download, AlertTriangle, RefreshCw } from 'lucide-react';

interface NavbarProps {
  activeTab: 'spend' | 'anomalies' | 'rightsizing' | 'chargeback' | 'accounts';
  onSelectTab: (tab: 'spend' | 'anomalies' | 'rightsizing' | 'chargeback' | 'accounts') => void;
  currency: Currency;
  onSelectCurrency: (c: Currency) => void;
  activeAnomalyCount: number;
  onOpenSimulateModal: () => void;
  onOpenExportModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onSelectTab,
  currency,
  onSelectCurrency,
  activeAnomalyCount,
  onOpenSimulateModal,
  onOpenExportModal,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-15 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400">
            <Cloud className="w-4 h-4" />
          </div>
          <button
            onClick={() => onSelectTab('spend')}
            className="text-base font-bold tracking-tight text-white hover:text-cyan-400 transition-colors cursor-pointer text-left"
          >
            VantagePoint <span className="text-cyan-400 font-medium">FinOps</span>
          </button>
        </div>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <button
            onClick={() => onSelectTab('spend')}
            className={`cursor-pointer transition-colors py-1 relative ${
              activeTab === 'spend'
                ? 'text-white font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400'
                : 'hover:text-white'
            }`}
          >
            Spend Visibility
          </button>

          <button
            onClick={() => onSelectTab('anomalies')}
            className={`cursor-pointer transition-colors py-1 flex items-center gap-1.5 relative ${
              activeTab === 'anomalies'
                ? 'text-white font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400'
                : 'hover:text-white'
            }`}
          >
            <span>Anomaly Alerts</span>
            {activeAnomalyCount > 0 && (
              <span className="text-xs font-mono font-semibold text-rose-400">
                ({activeAnomalyCount})
              </span>
            )}
          </button>

          <button
            onClick={() => onSelectTab('rightsizing')}
            className={`cursor-pointer transition-colors py-1 relative ${
              activeTab === 'rightsizing'
                ? 'text-white font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400'
                : 'hover:text-white'
            }`}
          >
            Rightsizing & Savings
          </button>

          <button
            onClick={() => onSelectTab('chargeback')}
            className={`cursor-pointer transition-colors py-1 relative ${
              activeTab === 'chargeback'
                ? 'text-white font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400'
                : 'hover:text-white'
            }`}
          >
            Chargeback & Units
          </button>

          <button
            onClick={() => onSelectTab('accounts')}
            className={`cursor-pointer transition-colors py-1 relative ${
              activeTab === 'accounts'
                ? 'text-white font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-cyan-400'
                : 'hover:text-white'
            }`}
          >
            Connected Clouds
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions & functional currency selector */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* Currency Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-md p-0.5 text-xs font-mono">
            {(['USD', 'EUR', 'GBP', 'JPY'] as Currency[]).map((c) => (
              <button
                key={c}
                onClick={() => onSelectCurrency(c)}
                className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                  currency === c
                    ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Test / Simulate Spike Action */}
          <button
            onClick={onOpenSimulateModal}
            title="Simulate Cloud Anomaly Spike"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-md transition-colors cursor-pointer whitespace-nowrap"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Spike</span>
          </button>

          {/* Export Report Action */}
          <button
            onClick={onOpenExportModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md shadow-xs transition-colors cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export FinOps</span>
          </button>
        </div>
      </div>

      {/* Mobile nav drawer tabs */}
      <div className="md:hidden flex items-center justify-between px-4 py-2 border-t border-slate-800/80 bg-slate-950 text-xs overflow-x-auto whitespace-nowrap gap-4">
        <button
          onClick={() => onSelectTab('spend')}
          className={`py-1 cursor-pointer ${activeTab === 'spend' ? 'text-cyan-400 font-semibold' : 'text-slate-400'}`}
        >
          Spend Visibility
        </button>
        <button
          onClick={() => onSelectTab('anomalies')}
          className={`py-1 cursor-pointer flex items-center gap-1 ${activeTab === 'anomalies' ? 'text-cyan-400 font-semibold' : 'text-slate-400'}`}
        >
          <span>Anomalies</span>
          {activeAnomalyCount > 0 && <span className="text-rose-400 font-mono">({activeAnomalyCount})</span>}
        </button>
        <button
          onClick={() => onSelectTab('rightsizing')}
          className={`py-1 cursor-pointer ${activeTab === 'rightsizing' ? 'text-cyan-400 font-semibold' : 'text-slate-400'}`}
        >
          Rightsizing
        </button>
        <button
          onClick={() => onSelectTab('chargeback')}
          className={`py-1 cursor-pointer ${activeTab === 'chargeback' ? 'text-cyan-400 font-semibold' : 'text-slate-400'}`}
        >
          Chargeback
        </button>
        <button
          onClick={() => onSelectTab('accounts')}
          className={`py-1 cursor-pointer ${activeTab === 'accounts' ? 'text-cyan-400 font-semibold' : 'text-slate-400'}`}
        >
          Clouds
        </button>
      </div>
    </header>
  );
};
