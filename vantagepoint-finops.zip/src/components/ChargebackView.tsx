import React, { useState, useMemo } from 'react';
import {
  ChargebackUnit,
  SharedCostPool,
  SharedAllocationMethod,
  Currency,
} from '../types/finops';
import {
  formatCurrency,
  formatPercent,
} from '../utils/formatters';
import {
  PieChart,
  Users,
  Building2,
  Share2,
  FileSpreadsheet,
  FileText,
  TrendingDown,
  TrendingUp,
  Download,
  Sliders,
  CheckCircle,
  HelpCircle,
  ChevronDown,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';

interface ChargebackViewProps {
  chargebackUnits: ChargebackUnit[];
  sharedPools: SharedCostPool[];
  currency: Currency;
}

export const ChargebackView: React.FC<ChargebackViewProps> = ({
  chargebackUnits,
  sharedPools,
  currency,
}) => {
  const [allocationMethod, setAllocationMethod] =
    useState<SharedAllocationMethod>('proportional');
  const [expandedUnitId, setExpandedUnitId] = useState<string | null>('cb-eng');
  const [selectedInvoiceUnit, setSelectedInvoiceUnit] =
    useState<ChargebackUnit | null>(null);

  // Total unallocated shared pool
  const totalSharedPoolAmount = useMemo(() => {
    return sharedPools.reduce((sum, p) => sum + p.totalAmount, 0);
  }, [sharedPools]);

  // Total direct spend across all units
  const totalDirectSpend = useMemo(() => {
    return chargebackUnits.reduce((sum, u) => sum + u.directSpend, 0);
  }, [chargebackUnits]);

  // Total headcount across all units
  const totalHeadcount = useMemo(() => {
    return chargebackUnits.reduce((sum, u) => sum + u.headcount, 0);
  }, [chargebackUnits]);

  // Recalculate allocated shared spend dynamically based on allocationMethod
  const computedUnits = useMemo(() => {
    return chargebackUnits.map((u) => {
      let allocatedShared = 0;
      if (allocationMethod === 'proportional') {
        const ratio = u.directSpend / (totalDirectSpend || 1);
        allocatedShared = Math.round(totalSharedPoolAmount * ratio);
      } else if (allocationMethod === 'headcount') {
        const ratio = u.headcount / (totalHeadcount || 1);
        allocatedShared = Math.round(totalSharedPoolAmount * ratio);
      } else {
        // Equal split
        allocatedShared = Math.round(totalSharedPoolAmount / (chargebackUnits.length || 1));
      }

      const totalSpend = u.directSpend + allocatedShared;
      const variancePct = ((totalSpend - u.budget) / u.budget) * 100;

      return {
        ...u,
        allocatedSharedSpend: allocatedShared,
        totalSpend,
        variancePct,
      };
    });
  }, [
    chargebackUnits,
    allocationMethod,
    totalSharedPoolAmount,
    totalDirectSpend,
    totalHeadcount,
  ]);

  const totalLoadedSpend = useMemo(() => {
    return computedUnits.reduce((sum, u) => sum + u.totalSpend, 0);
  }, [computedUnits]);

  const totalBudget = useMemo(() => {
    return computedUnits.reduce((sum, u) => sum + u.budget, 0);
  }, [computedUnits]);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Organizational Cost Accounting</span>
            <span aria-hidden="true">·</span>
            <span>Showback & Chargeback Engine</span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-400">FinOps Framework Certified</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Cost Allocation & Unit Economics
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setSelectedInvoiceUnit(computedUnits[0])}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Generate Team Invoices</span>
          </button>
        </div>
      </div>

      {/* Aggregate Overview Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Fully-Loaded Cloud Spend</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mb-1">
            {formatCurrency(totalLoadedSpend, currency)}
          </div>
          <div className="text-xs text-slate-400">
            Direct ({formatCurrency(totalDirectSpend, currency, true)}) + Shared (
            {formatCurrency(totalSharedPoolAmount, currency, true)})
          </div>
        </div>

        {/* Metric 2 */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Total Org Cloud Budget</div>
          <div className="text-2xl font-bold font-mono text-slate-200 tabular-nums mb-1">
            {formatCurrency(totalBudget, currency)}
          </div>
          <div className="text-xs text-emerald-400 font-mono">
            {formatPercent(((totalLoadedSpend - totalBudget) / totalBudget) * 100)} total variance
          </div>
        </div>

        {/* Metric 3 */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Unallocated Shared Pool</div>
          <div className="text-2xl font-bold font-mono text-cyan-300 tabular-nums mb-1">
            {formatCurrency(totalSharedPoolAmount, currency)}
          </div>
          <div className="text-xs text-slate-400">
            Across {sharedPools.length} enterprise infrastructure pools
          </div>
        </div>

        {/* Metric 4 */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Allocation Strategy</div>
          <div className="text-sm font-bold text-white capitalize mb-1">
            {allocationMethod.replace('_', ' ')} Allocation
          </div>
          <div className="text-[11px] text-slate-400">
            {allocationMethod === 'proportional'
              ? 'Shared costs weighted by direct cloud usage'
              : allocationMethod === 'headcount'
              ? 'Weighted by engineering team headcount'
              : 'Split evenly across 5 business units'}
          </div>
        </div>
      </div>

      {/* Shared Cost Redistribution Policy Bar */}
      <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">
              Shared Cost Redistribution Engine
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Allocate untagged infrastructure (Transit Gateways, Enterprise Support, K8s Ingress) to cost centers.
          </p>
        </div>

        {/* Dynamic Allocation Toggle */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono">
          <button
            onClick={() => setAllocationMethod('proportional')}
            className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
              allocationMethod === 'proportional'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Proportional to Direct
          </button>
          <button
            onClick={() => setAllocationMethod('headcount')}
            className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
              allocationMethod === 'headcount'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            By Headcount
          </button>
          <button
            onClick={() => setAllocationMethod('equal')}
            className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
              allocationMethod === 'equal'
                ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Equal Split (20% each)
          </button>
        </div>
      </div>

      {/* Shared Cost Pools Drawer/List */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
        {sharedPools.map((pool) => (
          <div
            key={pool.id}
            className="p-3 rounded-lg bg-slate-900/50 border border-slate-800/80 space-y-1"
          >
            <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
              <span>{pool.category}</span>
              <span className="text-white font-bold tabular-nums">
                {formatCurrency(pool.totalAmount, currency)}
              </span>
            </div>
            <div className="font-semibold text-slate-200 truncate">
              {pool.name}
            </div>
            <div className="text-[11px] text-slate-500 line-clamp-2">
              {pool.description}
            </div>
          </div>
        ))}
      </div>

      {/* Business Unit & Cost Center Allocation Cards */}
      <div className="space-y-4">
        <h2 className="text-base font-semibold text-white">
          Business Unit Invoices & Unit Economics
        </h2>

        <div className="space-y-3">
          {computedUnits.map((unit) => {
            const isExpanded = expandedUnitId === unit.id;
            const isOverBudget = unit.variancePct > 0;

            return (
              <div
                key={unit.id}
                className="rounded-xl bg-slate-900/50 border border-slate-800/80 overflow-hidden transition-all"
              >
                {/* Header row */}
                <div
                  onClick={() =>
                    setExpandedUnitId(isExpanded ? null : unit.id)
                  }
                  className="p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4 cursor-pointer hover:bg-slate-800/30 transition-colors"
                >
                  {/* Left: Code, Name, Lead */}
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-mono text-cyan-400 font-semibold">
                        {unit.code}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400">Lead: {unit.owner}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400 font-mono">{unit.headcount} Engineers</span>
                    </div>

                    <h3 className="text-base font-semibold text-white flex items-center gap-2">
                      <span>{unit.name}</span>
                      {isOverBudget ? (
                        <span className="text-[11px] font-mono text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20">
                          +{unit.variancePct.toFixed(1)}% OVER BUDGET
                        </span>
                      ) : (
                        <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                          ON TRACK
                        </span>
                      )}
                    </h3>
                  </div>

                  {/* Center: Unit Metric Badge */}
                  <div className="flex items-center gap-6 shrink-0">
                    <div className="p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 text-right min-w-[140px]">
                      <div className="text-[10px] text-slate-500 font-mono">
                        {unit.unitMetric.label}
                      </div>
                      <div className="text-sm font-bold font-mono text-white tabular-nums">
                        ${unit.unitMetric.value.toFixed(4)}
                        <span className="text-[10px] font-normal text-slate-400 ml-1">
                          {unit.unitMetric.unit}
                        </span>
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400">
                        {unit.unitMetric.trendPct}% YoY efficiency
                      </div>
                    </div>

                    {/* Spend Summary */}
                    <div className="text-right min-w-[120px]">
                      <div className="text-xs text-slate-400">Total Charged</div>
                      <div className="text-lg font-bold font-mono text-white tabular-nums">
                        {formatCurrency(unit.totalSpend, currency)}
                      </div>
                      <div className="text-xs font-mono text-slate-500">
                        Budget: {formatCurrency(unit.budget, currency)}
                      </div>
                    </div>

                    {/* Expand arrow */}
                    <div className="text-slate-400 p-1">
                      {isExpanded ? (
                        <ChevronDown className="w-5 h-5" />
                      ) : (
                        <ChevronRight className="w-5 h-5" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Sub-Teams Breakdown */}
                {isExpanded && (
                  <div className="border-t border-slate-800/80 bg-slate-950/40 p-4 space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>Sub-Team Cost Allocation & Primary Services</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedInvoiceUnit(unit);
                        }}
                        className="text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer flex items-center gap-1"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View Statement PDF Preview</span>
                      </button>
                    </div>

                    {/* Direct vs Shared Split Row */}
                    <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between text-xs font-mono">
                      <div>
                        <span className="text-slate-400">Direct Infrastructure: </span>
                        <strong className="text-white">
                          {formatCurrency(unit.directSpend, currency)}
                        </strong>
                      </div>
                      <div className="text-slate-600">+</div>
                      <div>
                        <span className="text-slate-400">Allocated Shared Pool: </span>
                        <strong className="text-cyan-300">
                          {formatCurrency(unit.allocatedSharedSpend, currency)}
                        </strong>
                      </div>
                      <div className="text-slate-600">=</div>
                      <div>
                        <span className="text-slate-400">Fully Loaded Invoice: </span>
                        <strong className="text-emerald-400">
                          {formatCurrency(unit.totalSpend, currency)}
                        </strong>
                      </div>
                    </div>

                    {/* Sub-teams table */}
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="border-b border-slate-800/60 text-slate-500 font-mono text-[11px]">
                            <th className="py-2 px-3">Team / Service Area</th>
                            <th className="py-2 px-3">Primary Cloud Driver</th>
                            <th className="py-2 px-3 text-right">Spend</th>
                            <th className="py-2 px-3 text-right">Allocated Budget</th>
                            <th className="py-2 px-3 text-right">Burn Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/40">
                          {unit.subTeams.map((sub, i) => {
                            const isSubOver = sub.spend > sub.budget;
                            return (
                              <tr key={i} className="hover:bg-slate-800/20">
                                <td className="py-2.5 px-3 font-medium text-slate-200">
                                  {sub.name}
                                </td>
                                <td className="py-2.5 px-3 text-slate-400 font-mono text-[11px]">
                                  {sub.primaryService}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono font-semibold text-white tabular-nums">
                                  {formatCurrency(sub.spend, currency)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono text-slate-400 tabular-nums">
                                  {formatCurrency(sub.budget, currency)}
                                </td>
                                <td className="py-2.5 px-3 text-right font-mono tabular-nums">
                                  <span
                                    className={
                                      isSubOver
                                        ? 'text-rose-400 font-semibold'
                                        : 'text-emerald-400'
                                    }
                                  >
                                    {isSubOver ? 'Over' : 'Under'} by{' '}
                                    {formatCurrency(
                                      Math.abs(sub.spend - sub.budget),
                                      currency,
                                      true
                                    )}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Chargeback Invoice Statement Modal */}
      {selectedInvoiceUnit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">
                  Internal Chargeback Statement · {selectedInvoiceUnit.code}
                </h3>
              </div>
              <button
                onClick={() => setSelectedInvoiceUnit(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs font-mono">
              <div className="border-b border-slate-800 pb-3 flex items-start justify-between">
                <div>
                  <div className="text-base font-bold text-white font-sans">
                    {selectedInvoiceUnit.name}
                  </div>
                  <div className="text-slate-400 text-xs">
                    Owner: {selectedInvoiceUnit.owner} ({selectedInvoiceUnit.leadEmail})
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    Cost Center: {selectedInvoiceUnit.code} · Billing Cycle: March 2026
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-slate-500 uppercase">Total Billed</div>
                  <div className="text-lg font-bold text-emerald-400 tabular-nums">
                    {formatCurrency(selectedInvoiceUnit.totalSpend, currency)}
                  </div>
                </div>
              </div>

              {/* Line items */}
              <div className="space-y-2">
                <div className="text-[11px] text-slate-400 uppercase font-sans font-semibold">
                  Direct Cost Sub-Allocations
                </div>
                {selectedInvoiceUnit.subTeams.map((sub, i) => (
                  <div key={i} className="flex justify-between py-1 border-b border-slate-800/40">
                    <span className="text-slate-300">{sub.name}</span>
                    <span className="text-white font-semibold tabular-nums">
                      {formatCurrency(sub.spend, currency)}
                    </span>
                  </div>
                ))}

                <div className="flex justify-between py-1 border-b border-slate-800/40 text-cyan-300">
                  <span>Shared Infrastructure Allocation ({allocationMethod})</span>
                  <span className="font-semibold tabular-nums">
                    {formatCurrency(selectedInvoiceUnit.allocatedSharedSpend, currency)}
                  </span>
                </div>
              </div>

              {/* Unit Economics Highlight */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="text-slate-400 text-[11px] mb-1">Unit Economic Efficiency</div>
                <div className="flex items-center justify-between">
                  <span className="text-white font-sans">{selectedInvoiceUnit.unitMetric.label}</span>
                  <span className="text-emerald-400 font-bold">
                    ${selectedInvoiceUnit.unitMetric.value} {selectedInvoiceUnit.unitMetric.unit} ({selectedInvoiceUnit.unitMetric.trendPct}%)
                  </span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  onClick={() => setSelectedInvoiceUnit(null)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-md transition-colors cursor-pointer"
                >
                  Close Statement
                </button>
                <button
                  onClick={() => {
                    alert(`Statement for ${selectedInvoiceUnit.code} exported to CSV successfully.`);
                    setSelectedInvoiceUnit(null);
                  }}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Statement CSV</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
