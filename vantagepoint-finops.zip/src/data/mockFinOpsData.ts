import {
  CloudAccount,
  CostDataPoint,
  ServiceSpend,
  Anomaly,
  RightsizingRecommendation,
  ChargebackUnit,
  SharedCostPool,
} from '../types/finops';

export const INITIAL_ACCOUNTS: CloudAccount[] = [
  {
    id: 'acc-aws-prod',
    name: 'AWS Production (Primary)',
    provider: 'aws',
    accountId: '8491-0392-4819',
    status: 'healthy',
    lastSync: '4 mins ago',
    monthlySpend: 154280,
    regionCount: 4,
    resourceCount: 1420,
  },
  {
    id: 'acc-gcp-data',
    name: 'GCP Data & Vertex AI',
    provider: 'gcp',
    accountId: 'prj-vertex-analytics-prod',
    status: 'healthy',
    lastSync: '12 mins ago',
    monthlySpend: 68450,
    regionCount: 2,
    resourceCount: 680,
  },
  {
    id: 'acc-azure-core',
    name: 'Azure Core Enterprise',
    provider: 'azure',
    accountId: 'sub-f8a190b2-3c22',
    status: 'healthy',
    lastSync: '18 mins ago',
    monthlySpend: 42390,
    regionCount: 3,
    resourceCount: 410,
  },
  {
    id: 'acc-k8s-multi',
    name: 'Kubernetes Multi-Cluster (EKS & GKE)',
    provider: 'k8s',
    accountId: 'k8s-mesh-prod',
    status: 'healthy',
    lastSync: '2 mins ago',
    monthlySpend: 19290,
    regionCount: 5,
    resourceCount: 184,
  },
];

// 30 days of historical data + 5 days forecast
export const GENERATE_COST_TIMELINE = (): CostDataPoint[] => {
  const points: CostDataPoint[] = [];
  const now = new Date();
  
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    
    // Weekend activity is ~25% lower on dev/staging
    const weekendFactor = isWeekend ? 0.78 : 1.0;
    
    // Baseline daily amounts
    let awsBase = (4900 + Math.sin(i * 0.4) * 350 + (29 - i) * 20) * weekendFactor;
    let gcpBase = (2200 + Math.cos(i * 0.3) * 200 + (29 - i) * 12) * weekendFactor;
    let azureBase = (1380 + Math.sin(i * 0.5) * 110) * weekendFactor;
    let k8sBase = (620 + Math.cos(i * 0.2) * 50) * weekendFactor;

    // Simulate real-world anomaly spike on days 23-25 (AWS NAT Gateway + GCP BigQuery runaway scan)
    if (i >= 4 && i <= 6) {
      awsBase += 1450; // NAT gateway egress surge
      gcpBase += 820;  // unindexed BigQuery partitioned scan
    }

    const total = Math.round(awsBase + gcpBase + azureBase + k8sBase);
    const budgetLimit = 9800; // daily budget threshold

    points.push({
      date: dateStr,
      dayLabel,
      aws: Math.round(awsBase),
      gcp: Math.round(gcpBase),
      azure: Math.round(azureBase),
      k8s: Math.round(k8sBase),
      total,
      budgetLimit,
      isForecast: false,
    });
  }

  // 5 Days Forecast projection
  const lastPoint = points[points.length - 1];
  for (let f = 1; f <= 5; f++) {
    const d = new Date(now);
    d.setDate(d.getDate() + f);
    const dateStr = d.toISOString().split('T')[0];
    const dayLabel = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    const isWeekend = d.getDay() === 0 || d.getDay() === 6;
    const weekendFactor = isWeekend ? 0.78 : 1.0;

    const awsF = Math.round(lastPoint.aws * (1 + f * 0.008) * weekendFactor);
    const gcpF = Math.round(lastPoint.gcp * (1 + f * 0.005) * weekendFactor);
    const azureF = Math.round(lastPoint.azure * weekendFactor);
    const k8sF = Math.round(lastPoint.k8s * weekendFactor);
    const total = awsF + gcpF + azureF + k8sF;

    points.push({
      date: dateStr,
      dayLabel: `${dayLabel} (Est)`,
      aws: awsF,
      gcp: gcpF,
      azure: azureF,
      k8s: k8sF,
      total,
      budgetLimit: 9800,
      isForecast: true,
    });
  }

  return points;
};

export const INITIAL_SERVICES: ServiceSpend[] = [
  {
    id: 'srv-1',
    service: 'Amazon EC2 (Elastic Compute)',
    provider: 'aws',
    category: 'Compute',
    mtdSpend: 62450,
    priorMonthSpend: 58900,
    changePct: 6.0,
    percentageOfTotal: 21.9,
    unitCostMetric: '$0.024 / vCPU-hr',
  },
  {
    id: 'srv-2',
    service: 'Google BigQuery & Analytics',
    provider: 'gcp',
    category: 'Database',
    mtdSpend: 34120,
    priorMonthSpend: 28400,
    changePct: 20.1,
    percentageOfTotal: 12.0,
    unitCostMetric: '$6.25 / TB scanned',
  },
  {
    id: 'srv-3',
    service: 'Amazon Relational Database (RDS)',
    provider: 'aws',
    category: 'Database',
    mtdSpend: 28900,
    priorMonthSpend: 29400,
    changePct: -1.7,
    percentageOfTotal: 10.2,
    unitCostMetric: '$0.18 / DB instance-hr',
  },
  {
    id: 'srv-4',
    service: 'Azure Virtual Machines (Compute)',
    provider: 'azure',
    category: 'Compute',
    mtdSpend: 24680,
    priorMonthSpend: 23900,
    changePct: 3.3,
    percentageOfTotal: 8.7,
    unitCostMetric: '$0.038 / core-hr',
  },
  {
    id: 'srv-5',
    service: 'Amazon Simple Storage Service (S3)',
    provider: 'aws',
    category: 'Storage',
    mtdSpend: 21400,
    priorMonthSpend: 19800,
    changePct: 8.1,
    percentageOfTotal: 7.5,
    unitCostMetric: '$0.023 / GB-mo',
  },
  {
    id: 'srv-6',
    service: 'Google Kubernetes Engine (GKE)',
    provider: 'gcp',
    category: 'Containers',
    mtdSpend: 18750,
    priorMonthSpend: 17200,
    changePct: 9.0,
    percentageOfTotal: 6.6,
    unitCostMetric: '$0.10 / cluster-hr',
  },
  {
    id: 'srv-7',
    service: 'AWS NAT Gateways & Egress Traffic',
    provider: 'aws',
    category: 'Networking',
    mtdSpend: 17350,
    priorMonthSpend: 12100,
    changePct: 43.4,
    percentageOfTotal: 6.1,
    unitCostMetric: '$0.045 / GB processed',
  },
  {
    id: 'srv-8',
    service: 'Google Vertex AI & LLM Inference',
    provider: 'gcp',
    category: 'AI & ML',
    mtdSpend: 15580,
    priorMonthSpend: 11200,
    changePct: 39.1,
    percentageOfTotal: 5.5,
    unitCostMetric: '$0.0018 / 1k tokens',
  },
  {
    id: 'srv-9',
    service: 'Azure Cosmos DB & Blob Storage',
    provider: 'azure',
    category: 'Storage',
    mtdSpend: 12890,
    priorMonthSpend: 13100,
    changePct: -1.6,
    percentageOfTotal: 4.5,
    unitCostMetric: '$0.008 / 100 RU/s',
  },
  {
    id: 'srv-10',
    service: 'Kubernetes Pod Resource Over-allocation',
    provider: 'k8s',
    category: 'Containers',
    mtdSpend: 9800,
    priorMonthSpend: 9200,
    changePct: 6.5,
    percentageOfTotal: 3.4,
    unitCostMetric: '52% unused pod requests',
  },
  {
    id: 'srv-11',
    service: 'AWS Elastic Load Balancing (ALB/NLB)',
    provider: 'aws',
    category: 'Networking',
    mtdSpend: 8490,
    priorMonthSpend: 8200,
    changePct: 3.5,
    percentageOfTotal: 3.0,
    unitCostMetric: '$0.0225 / LCU-hr',
  },
];

export const INITIAL_ANOMALIES: Anomaly[] = [
  {
    id: 'anom-101',
    title: 'Cross-AZ NAT Gateway Egress Spike in us-east-1',
    provider: 'aws',
    service: 'Amazon VPC / NAT Gateway',
    region: 'us-east-1',
    team: 'Platform Engineering',
    costSpikePerDay: 1420,
    percentIncrease: 340,
    baselineCostPerDay: 410,
    currentCostPerDay: 1830,
    severity: 'critical',
    detectedAt: 'Yesterday at 14:22 UTC',
    status: 'active',
    rootCause: 'Kubernetes pod daemonset in us-east-1b routing continuous image pulls and external telemetry through NAT Gateway instead of private VPC endpoints (S3 Gateway & ECR endpoints).',
    resourceId: 'nat-0e82c5890b21a3',
    sparklineData: [420, 390, 410, 440, 400, 430, 410, 1250, 1830, 1780],
    recommendation: 'Attach AWS VPC Endpoints for S3 (com.amazonaws.us-east-1.s3) and ECR. Eliminates NAT processing fees for internal telemetry.',
    environment: 'production',
  },
  {
    id: 'anom-102',
    title: 'Unindexed Partition Scans on BigQuery Event Logs',
    provider: 'gcp',
    service: 'Google BigQuery',
    region: 'us-central1',
    team: 'Data & AI',
    costSpikePerDay: 840,
    percentIncrease: 215,
    baselineCostPerDay: 390,
    currentCostPerDay: 1230,
    severity: 'high',
    detectedAt: '2 days ago',
    status: 'investigating',
    rootCause: 'New scheduled dbt pipeline run `fct_user_touchpoints` omitting `_PARTITIONTIME` filter, repeatedly performing full 52TB historical table scans every 4 hours.',
    resourceId: 'analytics_raw.events_stream_partitioned',
    sparklineData: [380, 410, 390, 400, 395, 410, 390, 890, 1150, 1230],
    recommendation: 'Enforce `require_partition_filter = true` on the BigQuery table schema. Refactor dbt query to constrain date ranges to `DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY)`.',
    environment: 'production',
  },
  {
    id: 'anom-103',
    title: 'Runaway GKE Node Autoscaling during Batch Job',
    provider: 'k8s',
    service: 'Google Kubernetes Engine',
    region: 'us-central1-a',
    team: 'Core ML Research',
    costSpikePerDay: 620,
    percentIncrease: 165,
    baselineCostPerDay: 375,
    currentCostPerDay: 995,
    severity: 'high',
    detectedAt: '3 days ago',
    status: 'active',
    rootCause: 'Uncapped Horizontal Pod Autoscaler (HPA) triggered by temporary cache warmers, scaling node pool from 6 to 34 `n2-standard-16` compute instances.',
    resourceId: 'gke-cluster-ml-prod/pool-v100-batch',
    sparklineData: [370, 360, 380, 375, 370, 380, 720, 940, 995, 960],
    recommendation: 'Set maxReplicas cap to 12 in the HPA configuration and configure Cluster Autoscaler maximum node limits with scale-down stabilization window.',
    environment: 'production',
  },
  {
    id: 'anom-104',
    title: 'Azure Premium SSD P30 Disks Retained Post-Decommission',
    provider: 'azure',
    service: 'Azure Managed Disks',
    region: 'eastus2',
    team: 'Customer Experience',
    costSpikePerDay: 260,
    percentIncrease: 88,
    baselineCostPerDay: 295,
    currentCostPerDay: 555,
    severity: 'medium',
    detectedAt: '5 days ago',
    status: 'resolved',
    rootCause: '14 unattached 1TB Premium SSD P30 disks left in unattached state following staging database migration.',
    resourceId: 'rg-cx-staging/disks/p30-*',
    sparklineData: [290, 300, 295, 290, 520, 560, 555, 310, 295, 290],
    recommendation: 'Deleted orphan disks and implemented Azure Policy rule to auto-tag detached disks with 72-hour expiration.',
    environment: 'staging',
  },
];

export const INITIAL_RECOMMENDATIONS: RightsizingRecommendation[] = [
  {
    id: 'rec-001',
    title: 'Migrate 8x c5.4xlarge to Graviton3 c7g.2xlarge',
    resourceId: 'i-09ab7234cde01',
    resourceType: 'EC2 Instance Pool',
    provider: 'aws',
    region: 'us-east-1',
    category: 'instance_downsize',
    currentConfig: '8x c5.4xlarge (16 vCPU, 32GB RAM)',
    proposedConfig: '8x c7g.2xlarge (8 vCPU, 16GB RAM Graviton3)',
    currentMonthlyCost: 4320,
    projectedMonthlyCost: 1980,
    monthlySavings: 2340,
    riskLevel: 'low',
    status: 'open',
    cpuAvgPct: 11.4,
    memoryAvgPct: 22.8,
    effort: 'Config Update',
    reasoning: '30-day telemetry shows average CPU utilization never breached 18.5% even during peak traffic. Graviton3 delivers 25% better price-performance with seamless ARM64 container compatibility.',
    iacSnippet: `resource "aws_launch_template" "api_workers" {
  name_prefix   = "api-worker-arm64-"
  image_id      = data.aws_ami.amazon_linux_2023_arm64.id
  instance_type = "c7g.2xlarge"

  instance_market_options {
    market_type = "spot" # Optional further 60% discount
  }
}`,
  },
  {
    id: 'rec-002',
    title: 'Clean Up 24 Unattached EBS gp3 Volumes (6.8 TB)',
    resourceId: 'vol-084f938217bb',
    resourceType: 'EBS Persistent Storage',
    provider: 'aws',
    region: 'us-west-2',
    category: 'idle_cleanup',
    currentConfig: '24 unattached gp3 volumes (0 I/O for >45 days)',
    proposedConfig: 'Snapshot final state & terminate unattached volumes',
    currentMonthlyCost: 1820,
    projectedMonthlyCost: 90,
    monthlySavings: 1730,
    riskLevel: 'no_risk',
    status: 'open',
    effort: 'Automated 1-Click',
    reasoning: 'Volumes were detached during Kubernetes worker node rebalancing and never deleted. Creating automated delta snapshots retains safety before termination.',
    iacSnippet: `# AWS CLI Cleanup Command:
aws ec2 describe-volumes --filters Name=status,Values=available \\
  --query 'Volumes[*].[VolumeId,Size]' --output table

# Automatic snapshot and purge script:
for vol in $(cat detached_vols.txt); do
  aws ec2 create-snapshot --volume-id $vol --description "Pre-delete backup"
  aws ec2 delete-volume --volume-id $vol
done`,
  },
  {
    id: 'rec-003',
    title: 'Commit to 1-Year Compute Savings Plan (AWS & GCP)',
    resourceId: 'sp-commit-2026',
    resourceType: 'Commitment Plan',
    provider: 'aws',
    region: 'Global',
    category: 'savings_plan',
    currentConfig: 'On-Demand hourly spend: $54.20/hr baseline',
    proposedConfig: '1-Year No-Upfront Compute Savings Plan @ $38.00/hr commit',
    currentMonthlyCost: 39024,
    projectedMonthlyCost: 27360,
    monthlySavings: 11664,
    riskLevel: 'no_risk',
    status: 'open',
    effort: 'Automated 1-Click',
    reasoning: 'Your steady-state minimum hourly compute spend across EC2, Fargate, and Lambda hasn\'t dropped below $44/hr in the last 180 days. A $38/hr commitment covers 82% of baseline with zero waste risk.',
    iacSnippet: `resource "aws_savingsplans_savings_plan" "compute_1yr" {
  savings_plan_offering_id = "sp-offering-compute-1yr-no-upfront"
  commitment               = "38.00" # USD per hour
}`,
  },
  {
    id: 'rec-004',
    title: 'Transition S3 `prod-analytics-lake` to Glacier Instant',
    resourceId: 'arn:aws:s3:::prod-analytics-lake',
    resourceType: 'S3 Object Storage',
    provider: 'aws',
    region: 'us-east-1',
    category: 'storage_tiering',
    currentConfig: '142 TB in S3 Standard (91% unaccessed >60 days)',
    proposedConfig: 'Lifecycle rule: Move to Glacier Instant Retrieval after 30 days',
    currentMonthlyCost: 3266,
    projectedMonthlyCost: 1136,
    monthlySavings: 2130,
    riskLevel: 'no_risk',
    status: 'open',
    effort: 'Config Update',
    reasoning: 'Access logs prove parquet partitions older than 30 days receive fewer than 2 read queries per month. Glacier Instant Retrieval provides millisecond access latency at a 65% discount.',
    iacSnippet: `resource "aws_s3_bucket_lifecycle_configuration" "analytics_tiering" {
  bucket = aws_s3_bucket.analytics_lake.id

  rule {
    id     = "archive-cold-data"
    status = "Enabled"

    transition {
      days          = 30
      storage_class = "GLACIER_IR" # Glacier Instant Retrieval
    }
  }
}`,
  },
  {
    id: 'rec-005',
    title: 'Downscale Azure SQL Database Staging Elastic Pool',
    resourceId: 'az-sql-pool-staging',
    resourceType: 'Azure SQL Elastic Pool',
    provider: 'azure',
    region: 'eastus',
    category: 'instance_downsize',
    currentConfig: 'General Purpose - Gen5 16 vCores (800 eDTU)',
    proposedConfig: 'General Purpose - Gen5 4 vCores (200 eDTU)',
    currentMonthlyCost: 2140,
    projectedMonthlyCost: 590,
    monthlySavings: 1550,
    riskLevel: 'low',
    status: 'open',
    cpuAvgPct: 6.2,
    memoryAvgPct: 19.4,
    effort: 'Config Update',
    reasoning: 'Elastic pool hosts 12 staging databases with cumulative peak DTU utilization of only 14%. Scaling down preserves failover capacity while cutting staging overhead by 72%.',
    iacSnippet: `resource "azurerm_mssql_elasticpool" "staging_pool" {
  name                = "sqlep-staging-eastus"
  resource_group_name = azurerm_resource_group.rg_staging.name
  location            = "eastus"
  server_name         = azurerm_mssql_server.db_server.name
  max_size_gb         = 756

  sku {
    name     = "GP_Gen5"
    tier     = "GeneralPurpose"
    family   = "Gen5"
    capacity = 4 # Downscale from 16 vCores
  }
}`,
  },
  {
    id: 'rec-006',
    title: 'Rightsize Kubernetes Pod Requests in GKE Clusters',
    resourceId: 'k8s-deployment-order-service',
    resourceType: 'Kubernetes Pod Deployment',
    provider: 'k8s',
    region: 'us-central1',
    category: 'instance_downsize',
    currentConfig: 'requests: cpu: 2000m, memory: 4Gi (Overprovisioned)',
    proposedConfig: 'requests: cpu: 500m, memory: 1.5Gi | limits: cpu: 2000m',
    currentMonthlyCost: 3120,
    projectedMonthlyCost: 1180,
    monthlySavings: 1940,
    riskLevel: 'medium',
    status: 'open',
    cpuAvgPct: 14.1,
    memoryAvgPct: 28.5,
    effort: 'Code Deploy',
    reasoning: 'Goldilocks telemetry reveals container actual utilization rarely exceeds 320m CPU. Tuning requests allows Kubernetes scheduler to binpack pods 3x more densely.',
    iacSnippet: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: order-service
spec:
  template:
    spec:
      containers:
      - name: app
        resources:
          requests:
            cpu: "500m"
            memory: "1536Mi"
          limits:
            cpu: "2000m"
            memory: "3072Mi"`,
  },
  {
    id: 'rec-007',
    title: 'Decommission 3 Zombie Classic Load Balancers',
    resourceId: 'elb-prod-web-legacy-01',
    resourceType: 'Classic Load Balancer',
    provider: 'aws',
    region: 'us-east-1',
    category: 'idle_cleanup',
    currentConfig: '3 Classic Load Balancers with 0 healthy registered targets',
    proposedConfig: 'Delete obsolete ELBs and DNS aliases',
    currentMonthlyCost: 1120,
    projectedMonthlyCost: 0,
    monthlySavings: 1120,
    riskLevel: 'no_risk',
    status: 'applied',
    effort: 'Automated 1-Click',
    reasoning: 'Replaced by Application Load Balancers (ALBs) 4 months ago during HTTP/2 migration. No DNS requests received in last 90 days.',
    iacSnippet: `# Completed: aws elb delete-load-balancer --load-balancer-name elb-prod-web-legacy-01`,
  },
];

export const INITIAL_CHARGEBACK_UNITS: ChargebackUnit[] = [
  {
    id: 'cb-eng',
    name: 'Core Platform & Infra',
    code: 'CC-1040',
    owner: 'Sarah Lin',
    leadEmail: 'sarah.lin@enterprise.internal',
    budget: 110000,
    directSpend: 96420,
    allocatedSharedSpend: 11200,
    totalSpend: 107620,
    variancePct: -2.2, // Under budget
    headcount: 38,
    unitMetric: {
      label: 'Cost / Pod Hour',
      value: 0.041,
      unit: '$/pod-hr',
      trendPct: -5.4,
    },
    subTeams: [
      { name: 'Kubernetes Platform', spend: 42100, budget: 44000, primaryService: 'EKS & GKE' },
      { name: 'Networking & Gateways', spend: 28400, budget: 27000, primaryService: 'NAT & DirectConnect' },
      { name: 'CI/CD & DevEx', spend: 25920, budget: 28000, primaryService: 'EC2 Runners' },
      { name: 'Security & Observability', spend: 11200, budget: 11000, primaryService: 'CloudWatch & Logs' },
    ],
  },
  {
    id: 'cb-ai',
    name: 'Data Science & Vertex AI',
    code: 'CC-2080',
    owner: 'Dr. Marcus Vance',
    leadEmail: 'm.vance@enterprise.internal',
    budget: 72000,
    directSpend: 68140,
    allocatedSharedSpend: 7800,
    totalSpend: 75940,
    variancePct: 5.5, // Over budget
    headcount: 24,
    unitMetric: {
      label: 'Cost / ML Inference',
      value: 0.0018,
      unit: '$/query',
      trendPct: -14.2,
    },
    subTeams: [
      { name: 'BigQuery Analytics', spend: 34120, budget: 30000, primaryService: 'Google BigQuery' },
      { name: 'LLM & Vertex AI', spend: 19820, budget: 18000, primaryService: 'Vertex AI Model Endpoints' },
      { name: 'Data Pipeline (dbt & Airflow)', spend: 14200, budget: 15000, primaryService: 'Cloud Composer' },
      { name: 'Feature Store', spend: 7800, budget: 9000, primaryService: 'Bigtable' },
    ],
  },
  {
    id: 'cb-prod',
    name: 'Product Engineering (Apps)',
    code: 'CC-3020',
    owner: 'Elena Rostova',
    leadEmail: 'elena.r@enterprise.internal',
    budget: 65000,
    directSpend: 54900,
    allocatedSharedSpend: 6200,
    totalSpend: 61100,
    variancePct: -6.0, // Under budget
    headcount: 45,
    unitMetric: {
      label: 'Cost / Active User (MAU)',
      value: 0.038,
      unit: '$/MAU',
      trendPct: -8.1,
    },
    subTeams: [
      { name: 'Core Checkout & Cart', spend: 24200, budget: 26000, primaryService: 'AWS RDS & ElastiCache' },
      { name: 'Search & Catalog', spend: 18100, budget: 20000, primaryService: 'OpenSearch' },
      { name: 'Mobile App Backend', spend: 12600, budget: 14000, primaryService: 'API Gateway & Lambda' },
      { name: 'Partner Integrations', spend: 6200, budget: 5000, primaryService: 'Azure Functions' },
    ],
  },
  {
    id: 'cb-cx',
    name: 'Customer Experience & CRM',
    code: 'CC-4010',
    owner: 'David Kalu',
    leadEmail: 'd.kalu@enterprise.internal',
    budget: 28000,
    directSpend: 24320,
    allocatedSharedSpend: 2400,
    totalSpend: 26720,
    variancePct: -4.6,
    headcount: 18,
    unitMetric: {
      label: 'Cost / Support Ticket',
      value: 0.42,
      unit: '$/ticket',
      trendPct: -3.0,
    },
    subTeams: [
      { name: 'Zendesk & Telephony Sync', spend: 14200, budget: 15000, primaryService: 'Azure VMs' },
      { name: 'Customer Knowledge Portal', spend: 10120, budget: 11000, primaryService: 'S3 & CloudFront' },
      { name: 'Satisfaction Feedback ETL', spend: 2400, budget: 2000, primaryService: 'EventBridge' },
    ],
  },
  {
    id: 'cb-mktg',
    name: 'Growth & Global Marketing',
    code: 'CC-5050',
    owner: 'Chloe Bennett',
    leadEmail: 'c.bennett@enterprise.internal',
    budget: 16000,
    directSpend: 13950,
    allocatedSharedSpend: 1400,
    totalSpend: 15350,
    variancePct: -4.1,
    headcount: 12,
    unitMetric: {
      label: 'Cost / Inbound Lead',
      value: 0.19,
      unit: '$/lead',
      trendPct: -11.5,
    },
    subTeams: [
      { name: 'SEO & Landing Page Edge', spend: 8100, budget: 9000, primaryService: 'CloudFront & Edge Lambdas' },
      { name: 'Marketing Attribution DB', spend: 5850, budget: 6000, primaryService: 'PostgreSQL RDS' },
      { name: 'Email Campaign Webhooks', spend: 1400, budget: 1000, primaryService: 'SNS & SQS' },
    ],
  },
];

export const SHARED_COST_POOLS: SharedCostPool[] = [
  {
    id: 'pool-enterprise-support',
    name: 'Enterprise Cloud Support (AWS & GCP)',
    totalAmount: 14200,
    category: 'Cloud Vendor Agreement',
    description: '24/7 business-critical response SLAs and technical account manager allocations.',
  },
  {
    id: 'pool-shared-k8s',
    name: 'Shared Kubernetes Ingress & Control Plane',
    totalAmount: 7800,
    category: 'Core Infrastructure',
    description: 'Cross-cluster Istio service mesh, Prometheus monitoring agents, and central ingress gateways.',
  },
  {
    id: 'pool-transit-vpc',
    name: 'Transit Gateway & Direct Connect Backbone',
    totalAmount: 4800,
    category: 'Networking',
    description: 'Shared hybrid-cloud interconnect between on-prem data centers, AWS us-east, and GCP.',
  },
  {
    id: 'pool-observability',
    name: 'Central Observability & Log Retention',
    totalAmount: 2200,
    category: 'Security & Audit',
    description: 'Central SIEM forwarding, long-term compliance log archives (SOX & ISO 27001).',
  },
];
