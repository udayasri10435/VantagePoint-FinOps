export type CloudProvider = 'aws' | 'gcp' | 'azure' | 'k8s';

export type Currency = 'USD' | 'EUR' | 'GBP' | 'JPY';

export interface CostDataPoint {
  date: string;
  dayLabel: string;
  aws: number;
  gcp: number;
  azure: number;
  k8s: number;
  total: number;
  budgetLimit: number;
  isForecast?: boolean;
}

export interface ServiceSpend {
  id: string;
  service: string;
  provider: CloudProvider;
  category: 'Compute' | 'Storage' | 'Database' | 'Networking' | 'AI & ML' | 'Containers';
  mtdSpend: number;
  priorMonthSpend: number;
  changePct: number;
  percentageOfTotal: number;
  unitCostMetric?: string;
}

export type AnomalySeverity = 'critical' | 'high' | 'medium';
export type AnomalyStatus = 'active' | 'investigating' | 'resolved' | 'dismissed';

export interface Anomaly {
  id: string;
  title: string;
  provider: CloudProvider;
  service: string;
  region: string;
  team: string;
  costSpikePerDay: number;
  percentIncrease: number;
  baselineCostPerDay: number;
  currentCostPerDay: number;
  severity: AnomalySeverity;
  detectedAt: string;
  status: AnomalyStatus;
  rootCause: string;
  resourceId: string;
  sparklineData: number[];
  recommendation: string;
  environment: 'production' | 'staging' | 'development';
}

export type RightsizingCategory = 'instance_downsize' | 'idle_cleanup' | 'savings_plan' | 'storage_tiering' | 'spot_migration';
export type RiskLevel = 'no_risk' | 'low' | 'medium';
export type RecommendationStatus = 'open' | 'applied' | 'dismissed';

export interface RightsizingRecommendation {
  id: string;
  title: string;
  resourceId: string;
  resourceType: string;
  provider: CloudProvider;
  region: string;
  category: RightsizingCategory;
  currentConfig: string;
  proposedConfig: string;
  currentMonthlyCost: number;
  projectedMonthlyCost: number;
  monthlySavings: number;
  riskLevel: RiskLevel;
  status: RecommendationStatus;
  cpuAvgPct?: number;
  memoryAvgPct?: number;
  iacSnippet: string;
  reasoning: string;
  effort: 'Automated 1-Click' | 'Config Update' | 'Code Deploy';
}

export interface ChargebackUnit {
  id: string;
  name: string;
  code: string;
  owner: string;
  leadEmail: string;
  budget: number;
  directSpend: number;
  allocatedSharedSpend: number;
  totalSpend: number;
  variancePct: number;
  headcount: number;
  unitMetric: {
    label: string;
    value: number;
    unit: string;
    trendPct: number;
  };
  subTeams: Array<{
    name: string;
    spend: number;
    budget: number;
    primaryService: string;
  }>;
}

export interface SharedCostPool {
  id: string;
  name: string;
  totalAmount: number;
  category: string;
  description: string;
}

export type SharedAllocationMethod = 'proportional' | 'headcount' | 'equal';

export interface CloudAccount {
  id: string;
  name: string;
  provider: CloudProvider;
  accountId: string;
  status: 'healthy' | 'syncing' | 'warning';
  lastSync: string;
  monthlySpend: number;
  regionCount: number;
  resourceCount: number;
}
