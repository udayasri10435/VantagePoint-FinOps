import React, { useState } from 'react';
import { Anomaly, CloudProvider } from '../types/finops';
import { AlertTriangle, Sparkles, X, Zap } from 'lucide-react';
import { PROVIDER_META } from '../utils/formatters';

interface SimulateAnomalyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAnomaly: (anomaly: Anomaly) => void;
}

const PRESET_SPIKES = [
  {
    title: 'Runaway NAT Gateway Egress in eu-west-1',
    provider: 'aws' as CloudProvider,
    service: 'Amazon VPC / NAT Gateway',
    region: 'eu-west-1',
    team: 'Platform Engineering',
    costSpikePerDay: 1650,
    percentIncrease: 380,
    baselineCostPerDay: 320,
    currentCostPerDay: 1970,
    severity: 'critical' as const,
    rootCause: 'Continuous Docker layer re-pulls passing through NAT Gateway instead of private AWS PrivateLink / VPC S3 endpoint.',
    recommendation: 'Configure VPC S3 Gateway endpoint to route container image pulls locally at zero egress cost.',
    resourceId: 'nat-07fa29910d',
    environment: 'production' as const,
  },
  {
    title: 'Uncapped Vertex AI GPU Autoscaling (A100)',
    provider: 'gcp' as CloudProvider,
    service: 'Google Vertex AI',
    region: 'us-central1',
    team: 'Core ML Research',
    costSpikePerDay: 2840,
    percentIncrease: 520,
    baselineCostPerDay: 540,
    currentCostPerDay: 3380,
    severity: 'critical' as const,
    rootCause: 'Batch evaluation job triggered unbounded horizontal replica expansion of 16x a2-highgpu-1g instances.',
    recommendation: 'Add quota limits and strict MaxReplicaCount = 4 in the Vertex custom job configuration.',
    resourceId: 'endpoint-a100-batch-eval',
    environment: 'production' as const,
  },
  {
    title: 'BigQuery Partition Filter Bypass on Raw Analytics',
    provider: 'gcp' as CloudProvider,
    service: 'Google BigQuery',
    region: 'us-central1',
    team: 'Data Science',
    costSpikePerDay: 920,
    percentIncrease: 240,
    baselineCostPerDay: 380,
    currentCostPerDay: 1300,
    severity: 'high' as const,
    rootCause: 'Ad-hoc BI dashboard query omitted partition filters, repeatedly scanning 65TB tables on 10-minute intervals.',
    recommendation: 'Enable require_partition_filter option on bigquery dataset tables.',
    resourceId: 'analytics_lake.user_behavior_logs',
    environment: 'production' as const,
  },
  {
    title: 'Orphaned Azure Premium SSD Disks Post-Cutover',
    provider: 'azure' as CloudProvider,
    service: 'Azure Managed Disks',
    region: 'eastus2',
    team: 'Product Engineering',
    costSpikePerDay: 480,
    percentIncrease: 120,
    baselineCostPerDay: 390,
    currentCostPerDay: 870,
    severity: 'medium' as const,
    rootCause: '12x 2TB Premium SSD disks left unattached following cluster database storage migration.',
    recommendation: 'Execute automated snapshot retention policy and delete detached disks.',
    resourceId: 'rg-prod/disks/p40-data-*',
    environment: 'production' as const,
  },
];

export const SimulateAnomalyModal: React.FC<SimulateAnomalyModalProps> = ({
  isOpen,
  onClose,
  onAddAnomaly,
}) => {
  const [selectedPresetIndex, setSelectedPresetIndex] = useState(0);

  if (!isOpen) return null;

  const handleSimulate = () => {
    const preset = PRESET_SPIKES[selectedPresetIndex];
    const newAnomaly: Anomaly = {
      ...preset,
      id: `anom-${Date.now()}`,
      detectedAt: 'Just now (Simulated)',
      status: 'active',
      sparklineData: [
        preset.baselineCostPerDay,
        preset.baselineCostPerDay + 20,
        preset.baselineCostPerDay - 10,
        preset.baselineCostPerDay + 15,
        preset.baselineCostPerDay,
        preset.baselineCostPerDay + 30,
        preset.baselineCostPerDay * 1.5,
        preset.currentCostPerDay * 0.9,
        preset.currentCostPerDay,
      ],
    };

    onAddAnomaly(newAnomaly);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">
              Simulate Real-World Cost Spike Anomaly
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs">
          <p className="text-slate-300">
            Select an incident pattern to test the FinOps detection engine, threshold alert rules, and incident workflow:
          </p>

          <div className="space-y-2">
            {PRESET_SPIKES.map((spike, idx) => {
              const meta = PROVIDER_META[spike.provider];
              const isSelected = selectedPresetIndex === idx;

              return (
                <div
                  key={idx}
                  onClick={() => setSelectedPresetIndex(idx)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/80 border-cyan-500 shadow-xs'
                      : 'bg-slate-950 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`font-mono font-semibold ${meta.textColor}`}>
                      {meta.shortName} · {spike.service}
                    </span>
                    <span className="font-mono text-rose-400 font-bold">
                      +${spike.costSpikePerDay}/day (+{spike.percentIncrease}%)
                    </span>
                  </div>
                  <div className="font-semibold text-white text-xs mb-1">
                    {spike.title}
                  </div>
                  <div className="text-slate-400 text-[11px] line-clamp-2">
                    {spike.rootCause}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-md transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSimulate}
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Inject Anomaly into Engine</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
