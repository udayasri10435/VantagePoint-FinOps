import React, { useState, useMemo } from 'react';
import { Anomaly, AnomalySeverity, AnomalyStatus, Currency } from '../types/finops';
import { formatCurrency, formatPercent, PROVIDER_META } from '../utils/formatters';
import {
  AlertTriangle,
  CheckCircle,
  Clock,
  Sparkles,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  ShieldAlert,
  Sliders,
  X,
  Copy,
  Terminal,
  FileText,
  BellRing,
} from 'lucide-react';

interface AnomalyAlertsViewProps {
  anomalies: Anomaly[];
  currency: Currency;
  onUpdateStatus: (id: string, status: AnomalyStatus) => void;
  onOpenSimulateModal: () => void;
}

export const AnomalyAlertsView: React.FC<AnomalyAlertsViewProps> = ({
  anomalies,
  currency,
  onUpdateStatus,
  onOpenSimulateModal,
}) => {
  const [selectedAnomaly, setSelectedAnomaly] = useState<Anomaly | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [sensitivity, setSensitivity] = useState<'high' | 'medium' | 'low'>('medium');
  const [copiedIncidentId, setCopiedIncidentId] = useState<string | null>(null);

  // Filtered anomalies
  const filteredAnomalies = useMemo(() => {
    return anomalies.filter((a) => {
      const matchStatus =
        filterStatus === 'all'
          ? true
          : filterStatus === 'active'
          ? a.status === 'active' || a.status === 'investigating'
          : a.status === filterStatus;
      const matchSeverity =
        filterSeverity === 'all' ? true : a.severity === filterSeverity;
      return matchStatus && matchSeverity;
    });
  }, [anomalies, filterStatus, filterSeverity]);

  // Aggregate metrics
  const activeCount = anomalies.filter(
    (a) => a.status === 'active' || a.status === 'investigating'
  ).length;

  const totalDailyWaste = anomalies
    .filter((a) => a.status === 'active' || a.status === 'investigating')
    .reduce((sum, a) => sum + a.costSpikePerDay, 0);

  const annualizedRunRateImpact = totalDailyWaste * 365;

  const handleCopyTicket = (anomaly: Anomaly) => {
    const report = `[FINOPS INCIDENT ALERT] ${anomaly.title}
Provider: ${anomaly.provider.toUpperCase()} | Region: ${anomaly.region} | Team: ${anomaly.team}
Severity: ${anomaly.severity.toUpperCase()}
Cost Impact: +$${anomaly.costSpikePerDay}/day (+${anomaly.percentIncrease}% vs baseline)
Resource ID: ${anomaly.resourceId}
Root Cause: ${anomaly.rootCause}
Remediation: ${anomaly.recommendation}`;
    navigator.clipboard.writeText(report);
    setCopiedIncidentId(anomaly.id);
    setTimeout(() => setCopiedIncidentId(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Machine Learning Anomaly Detection</span>
            <span aria-hidden="true">·</span>
            <span>Real-time Spend Surge Analyzer</span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-400">15-minute polling interval</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Cost Anomaly Detection & Incident Response
          </h1>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenSimulateModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-md transition-colors cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Cloud Spike</span>
          </button>
        </div>
      </div>

      {/* Detection Banner & Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Banner 1: Active Anomaly Count */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Active Incidents</div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums mb-1">
            {activeCount} {activeCount === 1 ? 'Spike' : 'Spikes'} Detected
          </div>
          <div className="text-xs text-slate-400">
            {anomalies.filter((a) => a.severity === 'critical').length} Critical ·{' '}
            {anomalies.filter((a) => a.severity === 'high').length} High priority
          </div>
        </div>

        {/* Banner 2: Est. Daily Excess Burn */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-1">Daily Unbudgeted Burn</div>
          <div className="text-2xl font-bold font-mono text-rose-400 tabular-nums mb-1">
            +{formatCurrency(totalDailyWaste, currency)} / day
          </div>
          <div className="text-xs text-slate-400">
            ~{formatCurrency(annualizedRunRateImpact, currency, true)} / yr unmitigated run rate
          </div>
        </div>

        {/* Banner 3: ML Sensitivity Threshold */}
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800/80">
          <div className="text-xs text-slate-400 mb-2">Detection Sensitivity</div>
          <div className="flex items-center gap-1 p-0.5 bg-slate-950 border border-slate-800 rounded-md text-xs font-mono">
            <button
              onClick={() => setSensitivity('high')}
              className={`flex-1 py-1 rounded transition-colors cursor-pointer ${
                sensitivity === 'high'
                  ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              High (15%)
            </button>
            <button
              onClick={() => setSensitivity('medium')}
              className={`flex-1 py-1 rounded transition-colors cursor-pointer ${
                sensitivity === 'medium'
                  ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Medium (25%)
            </button>
            <button
              onClick={() => setSensitivity('low')}
              className={`flex-1 py-1 rounded transition-colors cursor-pointer ${
                sensitivity === 'low'
                  ? 'bg-slate-800 text-cyan-300 font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Low (40%)
            </button>
          </div>
          <div className="text-[11px] text-slate-500 mt-2">
            Dynamic Holt-Winters exponential smoothing model with weekend calibration.
          </div>
        </div>
      </div>

      {/* Filter and Status Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-1">
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
          {[
            { id: 'all', label: 'All Incidents' },
            { id: 'active', label: 'Active & In Review' },
            { id: 'resolved', label: 'Resolved' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1.5 font-medium rounded-md transition-colors cursor-pointer ${
                filterStatus === tab.id
                  ? 'bg-slate-800 text-white font-semibold shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Severity:</span>
          {(['all', 'critical', 'high', 'medium'] as const).map((sev) => (
            <button
              key={sev}
              onClick={() => setFilterSeverity(sev)}
              className={`px-2.5 py-1 rounded capitalize border transition-colors cursor-pointer ${
                filterSeverity === sev
                  ? 'bg-slate-800 text-white border-slate-700 font-medium'
                  : 'text-slate-400 border-transparent hover:text-slate-200'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>
      </div>

      {/* Anomalies List */}
      <div className="space-y-3">
        {filteredAnomalies.length === 0 ? (
          <div className="p-8 text-center rounded-xl bg-slate-900/40 border border-slate-800/80 text-slate-400 text-sm">
            No anomalies found matching current filters.
          </div>
        ) : (
          filteredAnomalies.map((anomaly) => {
            const meta = PROVIDER_META[anomaly.provider];
            const isResolved = anomaly.status === 'resolved';
            const isInvestigating = anomaly.status === 'investigating';

            return (
              <div
                key={anomaly.id}
                className={`p-4 rounded-xl border transition-all ${
                  anomaly.severity === 'critical' && !isResolved
                    ? 'bg-rose-950/20 border-rose-900/40 hover:border-rose-700/60'
                    : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700/80'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Provider, Title, and Metadata */}
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`font-mono font-semibold ${meta.textColor}`}>
                        {meta.shortName}
                      </span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400">{anomaly.service}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400 font-mono">{anomaly.region}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-400">{anomaly.team}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="text-slate-500">{anomaly.detectedAt}</span>
                    </div>

                    <h3 className="text-base font-semibold text-white tracking-tight flex items-center gap-2 truncate">
                      <span>{anomaly.title}</span>
                      {anomaly.severity === 'critical' && !isResolved && (
                        <span className="text-[11px] font-mono font-semibold text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/30">
                          CRITICAL SPIKE
                        </span>
                      )}
                    </h3>

                    <p className="text-xs text-slate-300 line-clamp-2">
                      {anomaly.rootCause}
                    </p>
                  </div>

                  {/* Middle: Sparkline & Spend Surge */}
                  <div className="flex items-center gap-6 shrink-0">
                    {/* Sparkline 10-day preview */}
                    <div className="flex flex-col items-end">
                      <div className="text-[10px] text-slate-500 font-mono mb-1">
                        10-Day Trend
                      </div>
                      <div className="w-24 h-7 flex items-end gap-1">
                        {anomaly.sparklineData.map((val, idx) => {
                          const maxVal = Math.max(...anomaly.sparklineData);
                          const hPct = Math.max(12, Math.round((val / maxVal) * 100));
                          const isRecentSpike = idx >= anomaly.sparklineData.length - 3;
                          return (
                            <div
                              key={idx}
                              style={{ height: `${hPct}%` }}
                              className={`flex-1 rounded-xs transition-all ${
                                isRecentSpike
                                  ? 'bg-rose-500'
                                  : 'bg-slate-700 group-hover:bg-slate-600'
                              }`}
                              title={`Day -${anomaly.sparklineData.length - 1 - idx}: $${val}`}
                            />
                          );
                        })}
                      </div>
                    </div>

                    {/* Magnitude */}
                    <div className="text-right">
                      <div className="text-xs text-slate-400">Excess Burn</div>
                      <div className="text-lg font-bold font-mono text-rose-400 tabular-nums">
                        +{formatCurrency(anomaly.costSpikePerDay, currency)}
                        <span className="text-xs font-normal text-slate-400">/day</span>
                      </div>
                      <div className="text-xs font-mono text-rose-400">
                        +{anomaly.percentIncrease}% vs baseline
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
                      <button
                        onClick={() => setSelectedAnomaly(anomaly)}
                        className="px-3 py-1.5 text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors cursor-pointer flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <span>Investigate</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>

                      {isResolved ? (
                        <span className="text-xs text-emerald-400 font-mono px-2 py-1 flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          Resolved
                        </span>
                      ) : (
                        <button
                          onClick={() =>
                            onUpdateStatus(
                              anomaly.id,
                              isInvestigating ? 'resolved' : 'investigating'
                            )
                          }
                          className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                        >
                          {isInvestigating ? 'Mark Resolved' : 'Acknowledge'}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Slide-out Diagnostic Drawer / Modal for Detailed Investigation */}
      {selectedAnomaly && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <h3 className="text-sm font-semibold text-white">
                  Anomaly Root Cause Diagnostic #{selectedAnomaly.id}
                </h3>
              </div>
              <button
                onClick={() => setSelectedAnomaly(null)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              <div>
                <h4 className="text-base font-bold text-white mb-1">
                  {selectedAnomaly.title}
                </h4>
                <div className="flex items-center gap-2 text-slate-400 font-mono">
                  <span>Resource: {selectedAnomaly.resourceId}</span>
                  <span aria-hidden="true">·</span>
                  <span>Env: {selectedAnomaly.environment}</span>
                </div>
              </div>

              {/* Financial Surge Comparison */}
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg">
                <div>
                  <div className="text-slate-500">Normal Baseline</div>
                  <div className="text-base font-bold font-mono text-slate-300">
                    {formatCurrency(selectedAnomaly.baselineCostPerDay, currency)}/day
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Current Cost</div>
                  <div className="text-base font-bold font-mono text-rose-400">
                    {formatCurrency(selectedAnomaly.currentCostPerDay, currency)}/day
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Spike Jump</div>
                  <div className="text-base font-bold font-mono text-rose-400">
                    +{selectedAnomaly.percentIncrease}%
                  </div>
                </div>
              </div>

              {/* Root Cause Details */}
              <div className="space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Telemetry & Correlation Analysis</span>
                </div>
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 font-mono leading-relaxed">
                  {selectedAnomaly.rootCause}
                </div>
              </div>

              {/* Recommended Fix */}
              <div className="space-y-1.5">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Remediation Recommendation</span>
                </div>
                <div className="p-3 bg-slate-950 border border-emerald-950/40 rounded-lg text-emerald-300 font-sans leading-relaxed">
                  {selectedAnomaly.recommendation}
                </div>
              </div>

              {/* Incident Workflow Actions */}
              <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-800">
                <button
                  onClick={() => handleCopyTicket(selectedAnomaly)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>
                    {copiedIncidentId === selectedAnomaly.id
                      ? 'Copied to Clipboard!'
                      : 'Copy Incident Report'}
                  </span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onUpdateStatus(
                        selectedAnomaly.id,
                        selectedAnomaly.status === 'resolved' ? 'active' : 'resolved'
                      );
                      setSelectedAnomaly(null);
                    }}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-md transition-colors cursor-pointer"
                  >
                    {selectedAnomaly.status === 'resolved'
                      ? 'Reopen Anomaly'
                      : 'Resolve Anomaly'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
