import React, { useState } from 'react';
import { CloudAccount, Currency } from '../types/finops';
import { formatCurrency, PROVIDER_META } from '../utils/formatters';
import {
  Cloud,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Plus,
  Server,
  FileSpreadsheet,
  Upload,
  Copy,
  Terminal,
  ShieldCheck,
  Check,
} from 'lucide-react';

interface ConnectedCloudsProps {
  accounts: CloudAccount[];
  currency: Currency;
  onAddAccount: (acc: CloudAccount) => void;
  onRefreshSync: (id: string) => void;
  onLoadPreset: (preset: 'enterprise' | 'ai_startup' | 'fintech') => void;
}

export const ConnectedCloudsView: React.FC<ConnectedCloudsProps> = ({
  accounts,
  currency,
  onAddAccount,
  onRefreshSync,
  onLoadPreset,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [activeProviderTab, setActiveProviderTab] = useState<'aws' | 'gcp' | 'azure' | 'k8s'>('aws');
  const [accountName, setAccountName] = useState('');
  const [accountId, setAccountId] = useState('');
  const [isSyncingId, setIsSyncingId] = useState<string | null>(null);
  const [copiedHelm, setCopiedHelm] = useState(false);
  const [focusCsvFeedback, setFocusCsvFeedback] = useState<string | null>(null);

  const handleSync = (id: string) => {
    setIsSyncingId(id);
    setTimeout(() => {
      onRefreshSync(id);
      setIsSyncingId(null);
    }, 1200);
  };

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountName || !accountId) return;

    const newAcc: CloudAccount = {
      id: `acc-${Date.now()}`,
      name: accountName,
      provider: activeProviderTab,
      accountId,
      status: 'healthy',
      lastSync: 'Just now',
      monthlySpend: Math.round(20000 + Math.random() * 40000),
      regionCount: activeProviderTab === 'aws' ? 4 : 2,
      resourceCount: Math.round(150 + Math.random() * 300),
    };

    onAddAccount(newAcc);
    setAccountName('');
    setAccountId('');
    setShowAddModal(false);
  };

  const handleFocusCsvSim = () => {
    setFocusCsvFeedback('Validating FOCUS 1.0 Schema (BilledCost, ProviderName, ChargeCategory)...');
    setTimeout(() => {
      setFocusCsvFeedback('Successfully ingested 14,280 FOCUS billing rows. Cost metrics synchronized.');
      setTimeout(() => setFocusCsvFeedback(null), 4000);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
            <span>Multi-Cloud Infrastructure Connectors</span>
            <span aria-hidden="true">·</span>
            <span>Zero-Agent API Read-Only Roles</span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-400">FOCUS 1.0 Specification</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            Connected Cloud Providers & Ingestion Pipelines
          </h1>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-900 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Connect Cloud Account</span>
          </button>
        </div>
      </div>

      {/* Cloud Accounts List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {accounts.map((acc) => {
          const meta = PROVIDER_META[acc.provider];
          const isSyncing = isSyncingId === acc.id;

          return (
            <div
              key={acc.id}
              className="p-5 rounded-xl bg-slate-900/50 border border-slate-800/80 space-y-4 hover:border-slate-700/80 transition-all"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 text-xs mb-1">
                    <span className={`font-mono font-semibold ${meta.textColor}`}>
                      {meta.name}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Active Sync
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white tracking-tight">
                    {acc.name}
                  </h3>
                  <div className="text-xs font-mono text-slate-400 mt-0.5">
                    Account / Project ID: {acc.accountId}
                  </div>
                </div>

                <button
                  onClick={() => handleSync(acc.id)}
                  disabled={isSyncing}
                  className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg border border-slate-700 transition-colors cursor-pointer disabled:opacity-50"
                  title="Trigger Manual Cost Refresh"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-cyan-400' : ''}`} />
                </button>
              </div>

              {/* Account Stats */}
              <div className="grid grid-cols-3 gap-3 p-3 bg-slate-950/70 border border-slate-800/80 rounded-lg text-xs">
                <div>
                  <div className="text-slate-500">MTD Spend</div>
                  <div className="text-sm font-bold font-mono text-white tabular-nums">
                    {formatCurrency(acc.monthlySpend, currency)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Active Regions</div>
                  <div className="text-sm font-bold font-mono text-slate-200">
                    {acc.regionCount} Regions
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Monitored Items</div>
                  <div className="text-sm font-bold font-mono text-slate-200">
                    {acc.resourceCount} Assets
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                <span>Last telemetry ingest: {acc.lastSync}</span>
                <span className="text-cyan-400 font-mono text-[11px]">Read-Only IAM Policy</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* FOCUS 1.0 Specification & Dataset Simulator Section */}
      <div className="p-5 rounded-xl bg-slate-900/40 border border-slate-800/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
              <h2 className="text-base font-semibold text-white">
                FOCUS 1.0 Ingestion & Demo Dataset Modeling
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              VantagePoint FinOps natively ingests FinOps Open Cost & Usage Specification (FOCUS™) 1.0 normalized bills.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleFocusCsvSim}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
              <span>Simulate FOCUS CSV Import</span>
            </button>
          </div>
        </div>

        {focusCsvFeedback && (
          <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-lg text-xs font-mono text-cyan-300 animate-in fade-in">
            {focusCsvFeedback}
          </div>
        )}

        {/* Preset Environments */}
        <div className="border-t border-slate-800/80 pt-4">
          <div className="text-xs text-slate-400 mb-2">
            Load Preconfigured Industry FinOps Profiles:
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => onLoadPreset('enterprise')}
              className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-cyan-500/50 text-left transition-colors cursor-pointer group"
            >
              <div className="text-xs font-bold text-white group-hover:text-cyan-400">
                Global Enterprise SaaS
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                $284K/mo multi-cloud (AWS + GCP + Azure) with heavy analytics.
              </div>
            </button>

            <button
              onClick={() => onLoadPreset('ai_startup')}
              className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-cyan-500/50 text-left transition-colors cursor-pointer group"
            >
              <div className="text-xs font-bold text-white group-hover:text-cyan-400">
                AI / Foundation Model Startup
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                $410K/mo with heavy GPU clusters, GKE, and Vertex LLM inference.
              </div>
            </button>

            <button
              onClick={() => onLoadPreset('fintech')}
              className="p-3 rounded-lg bg-slate-950 border border-slate-800 hover:border-cyan-500/50 text-left transition-colors cursor-pointer group"
            >
              <div className="text-xs font-bold text-white group-hover:text-cyan-400">
                High-Compliance Fintech
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                $190K/mo with strict VPC isolation, high RDS IOPS, and audit retention.
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Connect Account Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
              <div className="flex items-center gap-2">
                <Cloud className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">
                  Connect Cloud Infrastructure
                </h3>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAccount} className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Provider picker */}
              <div>
                <label className="block text-slate-400 mb-1.5 font-medium">
                  Select Cloud Provider
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['aws', 'gcp', 'azure', 'k8s'] as const).map((p) => {
                    const meta = PROVIDER_META[p];
                    return (
                      <button
                        type="button"
                        key={p}
                        onClick={() => setActiveProviderTab(p)}
                        className={`p-2 rounded-lg border text-center font-mono cursor-pointer transition-colors ${
                          activeProviderTab === p
                            ? 'bg-slate-800 text-white border-cyan-500 font-semibold'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                        }`}
                      >
                        {meta.shortName}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Form inputs */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Account Display Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AWS Core Production or GCP ML Lab"
                  value={accountName}
                  onChange={(e) => setAccountName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-md text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  {activeProviderTab === 'aws'
                    ? 'AWS Account ID (12 digits) or Cross-Account Role ARN'
                    : activeProviderTab === 'gcp'
                    ? 'GCP Project ID'
                    : activeProviderTab === 'azure'
                    ? 'Azure Subscription ID'
                    : 'Kubernetes Cluster Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={
                    activeProviderTab === 'aws'
                      ? 'arn:aws:iam::123456789012:role/FinOpsCostReadOnly'
                      : activeProviderTab === 'gcp'
                      ? 'prj-core-production-381'
                      : activeProviderTab === 'azure'
                      ? 'sub-94b810ef-281a'
                      : 'eks-prod-us-east-1'
                  }
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-md text-white font-mono placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Instructions depending on provider */}
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-300 font-mono text-[11px] space-y-1">
                <div className="text-cyan-400 font-semibold flex items-center gap-1 font-sans">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Security & Zero-Write Policy</span>
                </div>
                <p>
                  VantagePoint FinOps requires strictly read-only permissions (`ce:GetCostAndUsage`, `monitoring:GetMetricData`). No credentials or write privileges are stored.
                </p>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 rounded-md transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer"
                >
                  Connect & Verify
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
