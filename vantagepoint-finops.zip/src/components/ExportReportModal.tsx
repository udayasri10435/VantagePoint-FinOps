import React, { useState } from 'react';
import { Currency, ServiceSpend, Anomaly, RightsizingRecommendation, ChargebackUnit } from '../types/finops';
import { formatCurrency, formatPercent } from '../utils/formatters';
import { Download, Printer, Copy, X, Check, FileText } from 'lucide-react';

interface ExportReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  mtdSpend: number;
  services: ServiceSpend[];
  anomalies: Anomaly[];
  recommendations: RightsizingRecommendation[];
  chargebackUnits: ChargebackUnit[];
}

export const ExportReportModal: React.FC<ExportReportModalProps> = ({
  isOpen,
  onClose,
  currency,
  mtdSpend,
  services,
  anomalies,
  recommendations,
  chargebackUnits,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const totalSavings = recommendations
    .filter((r) => r.status === 'open')
    .reduce((sum, r) => sum + r.monthlySavings, 0);

  const activeAnomalies = anomalies.filter(
    (a) => a.status === 'active' || a.status === 'investigating'
  );

  const handleCopyMarkdown = () => {
    const md = `# Executive FinOps Cloud Cost Report
Generated: ${new Date().toLocaleDateString()} | Focus: Multi-Cloud Spend & Optimization

## 1. High-Level Financial Summary
- Month-to-Date (MTD) Spend: ${formatCurrency(mtdSpend, currency)}
- Total Available Monthly Savings: ${formatCurrency(totalSavings, currency)} / mo
- Active Unresolved Anomalies: ${activeAnomalies.length} (${activeAnomalies.map((a) => a.title).join(', ')})

## 2. Top 5 Cloud Cost Drivers
${services
  .slice(0, 5)
  .map(
    (s, i) =>
      `${i + 1}. ${s.service} (${s.provider.toUpperCase()}): ${formatCurrency(
        s.mtdSpend,
        currency
      )} (${s.percentageOfTotal}% of total)`
  )
  .join('\n')}

## 3. High-Priority Rightsizing Actions
${recommendations
  .filter((r) => r.status === 'open')
  .slice(0, 3)
  .map(
    (r) =>
      `- [${r.provider.toUpperCase()}] ${r.title} — Save ${formatCurrency(
        r.monthlySavings,
        currency
      )}/mo (${r.riskLevel.toUpperCase()} RISK)`
  )
  .join('\n')}

## 4. Organizational Chargeback
${chargebackUnits
  .map(
    (u) =>
      `- ${u.name} (${u.code}): ${formatCurrency(u.totalSpend, currency)} (Budget: ${formatCurrency(
        u.budget,
        currency
      )})`
  )
  .join('\n')}
`;
    navigator.clipboard.writeText(md);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCsv = () => {
    const rows = [
      ['Service', 'Provider', 'Category', 'MTD Spend', 'Share Pct'],
      ...services.map((s) => [
        `"${s.service}"`,
        s.provider.toUpperCase(),
        s.category,
        s.mtdSpend.toString(),
        `${s.percentageOfTotal}%`,
      ]),
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `FinOps_Cost_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-white">
              Export FinOps Executive Briefing & Data
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 text-xs font-mono">
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg space-y-3 font-sans text-slate-300">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-sm">
                VantagePoint Executive FinOps Summary
              </span>
              <span className="text-slate-500 text-xs font-mono">
                {new Date().toISOString().split('T')[0]}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs font-mono pt-1">
              <div>
                <span className="text-slate-500 block">MTD Cloud Spend</span>
                <strong className="text-white text-sm">
                  {formatCurrency(mtdSpend, currency)}
                </strong>
              </div>
              <div>
                <span className="text-slate-500 block">Monthly Savings Potential</span>
                <strong className="text-emerald-400 text-sm">
                  {formatCurrency(totalSavings, currency)}/mo
                </strong>
              </div>
              <div>
                <span className="text-slate-500 block">Active Spikes</span>
                <strong className="text-rose-400 text-sm">
                  {activeAnomalies.length} Incidents
                </strong>
              </div>
            </div>

            <p className="text-xs text-slate-400 pt-2 border-t border-slate-800 leading-relaxed">
              This report compiles cross-cloud telemetry across AWS, Google Cloud, Microsoft Azure, and Kubernetes. Exportable for CFO / VP Engineering reviews and GitOps ticket systems.
            </p>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800">
            <button
              onClick={handleCopyMarkdown}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Markdown Copied!' : 'Copy Executive Markdown'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                onClick={handleDownloadCsv}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download FOCUS CSV</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
